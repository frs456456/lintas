@extends('master')

@section('konten')
</br>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">

            <div class="card">
                <div class="card-header">
                    Edit Data
                    <a href="{{ url('/perencanaan') }}" class="float-right btn btn-sm btn-primary">Kembali</a>
                </div>
                <div class="card-body">

                    <form method="post" action="{{ url('/perencanaan/update/'.$perencanaan->id) }}">

                        @csrf

                        {{ method_field('PUT') }}



                        <div class="form-group">

                            <label>Juz Ke</label>
                            <input type="number" name="jus_ke" class="form-control" value="{{$perencanaan->jus_ke}}">

                            @if($errors->has('jus_ke'))
                            <span class="text-danger">
                                <strong>{{ $errors->first('jus_ke') }}</strong>
                            </span>
                            @endif

                        </div>

                        <!-- <div class="form-group">

                            <label>Status</label>
                            <select class="form-control" name="status" id="">
                                <option <?php if ($perencanaan->status == "terlaksana") {
                                            echo "selcted='selected'";
                                        } ?> value="terlaksana">Sudah Terlaksana</option>


                                <option <?php if ($perencanaan->status == "belum") {
                                            echo "selected='selected'";
                                        } ?> value="belum">Belum Terlaksana</option>
                            </select>


                            @if($errors->has('status'))
                            <span class="text-danger">
                                <strong>{{ $errors->first('status') }}</strong>
                            </span>
                            @endif

                        </div> -->

                        <input type="submit" class="btn btn-primary" value="Simpan">

                    </form>

                </div>
            </div>

        </div>
    </div>
</div>
@endsection