@extends('master')

@section('konten')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">

            <div class="card">
                <div class="card-header">
                    Tambah Pembagian

                    <a href="{{ url('/SDM') }}" class="float-right btn btn-sm btn-primary">Kembali</a>
                </div>
                <div class="card-body">

                    <form method="post" action="{{ url('/SDM/aksi') }}">

                        @csrf


                        <div class="form-group">

                            <label>Juz Ke</label>
                            <input type="number" name="jus_ke" class="form-control">

                            @if($errors->has('jus_ke'))
                            <span class="text-danger">
                                <strong>{{ $errors->first('jus_ke') }}</strong>
                            </span>
                            @endif

                        </div>

                        <input type="submit" class="btn btn-primary" value="Simpan">

                    </form>

                </div>
            </div>

        </div>
    </div>
</div>
@endsection