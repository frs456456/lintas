@extends('master')

@section('konten')
</br>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">

            <div class="card">
                <div class="card-header">
                    Data Pegawai
                    <a href="{{ url('/pegawai_tambah') }}" class="float-right btn btn-sm btn-primary">Tambah</a>
                </div>
                </br>

                <div class="card-body">

                    @if(Session::has('sukses'))
                    <div class="alert alert-success">
                        {{ Session::get('sukses') }}
                    </div>
                    @endif

                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th width="1%">No</th>

                                <th>Nama Pegawai</th>
                                <th>Jabatan</th>
                                <th>Divisi</th>
                                <th>Agama</th>
                                <th width="15%" class="text-center">OPSI</th>
                            </tr>
                        </thead>

                        <tbody>

                            @php
                            $no = 1;
                            @endphp
                            @foreach($pegawai as $p)
                            <tr>
                                <td>{{ $no++ }}</td>
                                <td>{{ $p->nama_pegawai }}</td>
                                <td>{{$p->jabatan}}</td>
                                <td>{{$p->divisi}}</td>
                                <td>{{$p->agama}}</td>
                                <td class="text-center">
                                    <a href="{{ url('/pegawai_edit'.$p->id) }}" class="btn btn-sm btn-warning">Edit</a>
                                    <a href="{{ url('/pegawai/hapus/'.$p->id) }}" class="btn btn-sm btn-danger" onclick="return confirm('Yakin Hapus ??')">Hapus</a>
                                </td>
                            </tr>
                            @endforeach

                        </tbody>
                    </table>
                    {{ $pegawai->links() }}
                </div>
            </div>

        </div>
    </div>
</div>
@endsection