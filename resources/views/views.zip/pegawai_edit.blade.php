@extends('master')

@section('konten')

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">

            <div class="card">
                <div class="card-header">
                    Edit Data
                    <a href="{{ url('/pegawai') }}" class="float-right btn btn-sm btn-primary">Kembali</a>
                </div>
                <div class="card-body">

                    <form method="post" action="{{ url('/pegawai/update/'.$pegawai->id) }}">

                        @csrf

                        {{ method_field('PUT') }}

                        <div class="form-group">

                            <label>Nama Pegawai</label>
                            <input type="text" name="nama_pegawai" class="form-control" value="{{$pegawai->nama_pegawai}}">

                            @if($errors->has('nama_pegawai'))
                            <span class="text-danger">
                                <strong>{{ $errors->first('nama_pegawai') }}</strong>
                            </span>
                            @endif

                        </div>

                        <div class="form-group">

                            <label>Jabatan</label>
                            <select class="form-control" name="jabatan" id="">
                                <option <?php if ($pegawai->jabatan == "staff") {
                                            echo "selcted='selected'";
                                        } ?> value="staff">Staff</option>

                                <option <?php if ($pegawai->jabatan == "supervisor") {
                                            echo "selcted='selected'";
                                        } ?> value="supervisor">Supervisor</option>


                                <option <?php if ($pegawai->jabatan == "manajer") {
                                            echo "selected='selected'";
                                        } ?> value="manajer">Manajer</option>

                            </select>


                            @if($errors->has('jabatan'))
                            <span class="text-danger">
                                <strong>{{ $errors->first('jabatan') }}</strong>
                            </span>
                            @endif

                        </div>

                        <div class="form-group">

                            <label>Jabatan</label>
                            <select class="form-control" name="divisi" id="">
                                <option <?php if ($pegawai->divisi == "IT") {
                                            echo "selcted='selected'";
                                        } ?> value="IT">Teknologi Informasi</option>

                                <option <?php if ($pegawai->divisi == "SDM") {
                                            echo "selected='selected'";
                                        } ?> value="SDM">SDM</option>

                                <option <?php if ($pegawai->divisi == "pemasaran") {
                                            echo "selected='selected'";
                                        } ?> value="pemasaran">Pemasaran</option>

                                <option <?php if ($pegawai->divisi == "keuangan") {
                                            echo "selected='selected'";
                                        } ?> value="keuangan">Keuangan</option>
                                        
                                <option <?php if ($pegawai->divisi == "distribusi") {
                                            echo "selected='selected'";
                                        } ?> value="distribusi">Distribusi</option>

                            </select>


                            @if($errors->has('divisi'))
                            <span class="text-danger">
                                <strong>{{ $errors->first('divisi') }}</strong>
                            </span>
                            @endif

                        </div>

                        <div class="form-group">

                            <label>Agama</label>
                            <select class="form-control" name="agama" id="">
                                <option <?php if ($pegawai->agama == "islam") {
                                            echo "selcted='selected'";
                                        } ?> value="islam">Islam</option>


                                <option <?php if ($pegawai->agama == "Non Muslim") {
                                            echo "selected='selected'";
                                        } ?> value="Non Muslim">Non Muslim</option>
                            </select>


                            @if($errors->has('agama'))
                            <span class="text-danger">
                                <strong>{{ $errors->first('agama') }}</strong>
                            </span>
                            @endif

                        </div>

                        <input type="submit" class="btn btn-primary" value="Simpan">

                    </form>

                </div>
            </div>

        </div>
    </div>
</div>
@endsection