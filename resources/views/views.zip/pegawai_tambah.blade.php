@extends('master')

@section('konten')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">

            <div class="card">
                <div class="card-header">
                    Tambah Pegawai

                    <a href="{{ url('/pegawai') }}" class="float-right btn btn-sm btn-primary">Kembali</a>
                </div>
                <div class="card-body">

                    <form method="post" action="{{ url('/pegawai/aksi') }}">

                        @csrf

                        <div class="form-group">

                            <label>Nama Pegawai</label>
                            <input type="text" name="nama_pegawai" class="form-control">

                            @if($errors->has('nama_pegawai'))
                            <span class="text-danger">
                                <strong>{{ $errors->first('nama_pegawai') }}</strong>
                            </span>
                            @endif

                        </div>

                        <div class="form-group">

                            <label>Jabatan</label>
                            <select name="jabatan" id="" class="form-control">
                                <option value="">-Pilih Jabatan</option>
                                <option value="staff">Staff</option>
                                <option value="supervisor">Supervisor</option>
                                <option value="manajer">Manajer</option>
                            </select>

                            @if($errors->has('jabatan'))
                            <span class="text-danger">
                                <strong>{{ $errors->first('jabatan') }}</strong>
                            </span>
                            @endif

                        </div>

                        <div class="form-group">

                            <label>Divisi</label>
                            <select name="divisi" class="form-control" id="">
                                <option value="">-Pilih Divisi</option>
                                <option value="IT">Teknologi Informasi</option>
                                <option value="SDM">SDM</option>
                                <option value="pemasaran">Pemasaran</option>
                                <option value="keuangan">Keuangan</option>
                                <option value="distribusi">Distribusi</option>
                            </select>

                            @if($errors->has('divisi'))
                            <span class="text-danger">
                                <strong>{{ $errors->first('divisi') }}</strong>
                            </span>
                            @endif

                        </div>

                        <div class="form-group">

                            <label>Agama</label>
                            <select name="agama" id="" class="form-control">
                                <option value="">-Pilih Agama</option>
                                <option value="islam">Islam</option>
                                <option value="Non Muslim">Non Muslim</option>
                            </select>

                            @if($errors->has('agama'))
                            <span class="text-danger">
                                <strong>{{ $errors->first('agama') }}</strong>
                            </span>
                            @endif

                        </div>



                        <input type="submit" class="btn btn-primary" value="Simpan">

                    </form>

                </div>
            </div>

        </div>
    </div>
</div>
@endsection