@extends('master')

@section('konten')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                </div>
                <div class="card-body">

                    @if(Session::has('sukses'))
                    <div class="alert alert-success">
                        {{ Session::get('sukses') }}
                    </div>
                    @endif

                    <div class="row">
                        <div class="col-md-12">
                            <div class="panel panel-primary">
                                <div class="panel-heading">
                                    <h3 class="panel-title">Data Pegawai</h3>
                                </div>
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-xs-12">
                                            <div class="table-responsive" style="height: 200px;overflow: scroll;">
                                                <table id="datatable-responsive" class="table table-striped dt-responsive nowrap" cellspacing="0" width="100%">
                                                    <thead>
                                                        <tr>
                                                            <th width="1%">No</th>
                                                            <th>Nama Pegawai</th>
                                                            <th>Divisi</th>
                                                            <th>Link Pembagian</th>
                                                            <th>Status</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        @php
                                                        $noIT = 1;
                                                        $no = 1;
                                                        @endphp
                                                        @foreach($pegawaiPerencanaan as $p)
                                                        <tr>
                                                            <td>{{$no++}}</td>
                                                            <td>{{$p->name}}</td>
                                                            <td>{{$p->divisi}}</td>
                                                            <td><a href="{{ url('/pembagianPerencanaan?page=')}}{{$noIT++}}">Pembagian</a></td>
                                                            <td>{{$p->status}}</td>
                                                        </tr>
                                                        @endforeach
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> <!-- End row -->

                    <br>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="panel panel-success">
                                <div class="panel-heading">
                                    <h3 class="panel-title text-white">Pembagian Tilawah</h3>
                                </div>
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-xs-12">
                                            <div class="table-responsive">
                                                <table class="table table-striped">
                                                    <thead>
                                                        <tr>
                                                            <th width="1%">No</th>
                                                            <th>Nama Surat</th>
                                                            <th>Ayat Ke</th>
                                                            <th>Bacaan</th>
                                                            <th>Juz ke</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        @php
                                                        $no = 1;
                                                        @endphp
                                                        @foreach($pembagianPerencanaan as $pembagianPerencanaan)
                                                        <tr>
                                                            <td>{{ $no++ }}</td>
                                                            <td>{{ $pembagianPerencanaan->nama_surat }}</td>
                                                            <td>Ayat {{$pembagianPerencanaan->ayat_ke}}</td>
                                                            <td style="font-size: 25px; font-family:Scheherazade New;">{{$pembagianPerencanaan->bacaan}}</strong></td>
                                                            <td>Juz {{$pembagianPerencanaan->jus_ke}}</td>
                                                        </tr>
                                                        @endforeach
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> <!-- End row -->
                </div>
            </div>
        </div>
    </div>
</div>
@endsection