@extends('master')

@section('konten')
<?php

use Carbon\Carbon;
?>

<h4>Selamat Datang <b>{{Auth::user()->name}}</b>, Anda Login sebagai <b>{{Auth::user()->role}}</b>.</h4>
<div class="row">
    <div class="col-sm-4">
        <div class="panel panel-dark text-center">
            <div class="panel-heading">
                <h4 class="panel-title">Pemasaran</h4>
            </div>
            <div class="panel-body">

                <a href="{{url('/pembagianPemasaran')}}">
                    <?php if ($statusPemasaran == $jumlahrowPemasaran) { ?>
                        <h2>
                            <i class="mdi mdi-checkbox-marked-circle-outline text-success"></i>
                        </h2>

                    <?php
                    } else { ?>
                        <h2>
                            <i class="mdi mdi-timelapse text-danger"></i>
                        </h2>
                    <?php
                    } ?>
                    <h4>Juz ke {{$jus_ke1Pemasaran}} - {{$jus_ke6Pemasaran}}</h4>
                    <p class="text-muted"><b><?php echo date('l, d-m-Y'); ?></b></p>
                    <div class="progress">
                        <div class="progress-bar progress-bar-info progress-bar-striped active" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: <?php $Pemasaranprogres = $statusPemasaran / $jumlahrowPemasaran * 100;
                                                                                                                                                                                            echo $Pemasaranprogres ?>%">
                            <span class="sr-only">60% Complete</span>
                        </div>
                    </div>
            </div>
            </a>
        </div>
    </div>

    <div class="col-sm-4">
        <div class="panel panel-dark text-center">
            <div class="panel-heading">
                <h4 class="panel-title text-white">Teknologi Informasi</h4>
            </div>
            <div class="panel-body">
                <a href="{{url('/pembagianIT')}}">
                    <?php if ($statusIT == $jumlahrowIT) { ?>
                        <h2>
                            <i class="mdi mdi-checkbox-marked-circle-outline text-success"></i>
                        </h2>
                    <?php
                    } else { ?>
                        <h2>
                            <i class="mdi mdi-timelapse text-danger"></i>
                        </h2>
                    <?php
                    } ?>

                    <h4>Juz ke {{$jus_ke1IT}} - {{$jus_ke7IT}}</h4>
                    <p class="text-muted"><b><?php echo date('l, d-m-Y'); ?></b></p>
                    <div class="progress">
                        <div class="progress-bar progress-bar-info progress-bar-striped active" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: <?php $ITprogres = $statusIT / $jumlahrowIT * 100;
                                                                                                                                                                                            echo $ITprogres ?>%">
                            <span class="sr-only">60% Complete</span>
                        </div>
                    </div>
            </div>
            </a>
        </div>
    </div>
    <div class="col-sm-4">
        <div class="panel panel-dark text-center">
            <div class="panel-heading">
                <h4 class="panel-title text-white">SDM</h4>
            </div>
            <div class="panel-body">
                <a href="{{url('/pembagianSDM')}}">
                    <?php if ($statusSDM == $jumlahrowSDM) { ?>
                        <h2>
                            <i class="mdi mdi-checkbox-marked-circle-outline text-success"></i>
                        </h2>

                    <?php
                    } else { ?>
                        <h2>
                            <i class="mdi mdi-timelapse text-danger"></i>
                        </h2>
                    <?php
                    } ?>
                    <h4>Juz ke {{$jus_ke1SDM}} - {{$jus_ke7SDM}}</h4>
                    <p class="text-muted"><b><?php echo date('l, d-m-Y'); ?></b></p>
                    <div class="progress">
                        <div class="progress-bar progress-bar-info progress-bar-striped active" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: <?php $SDMprogres = $statusSDM / $jumlahrowSDM * 100;
                                                                                                                                                                                            echo $SDMprogres ?>%">
                            <span class="sr-only">60% Complete</span>
                        </div>
                    </div>
            </div>
            </a>
        </div>
    </div>
    <div class="col-sm-4">
        <div class="panel panel-dark text-center">
            <div class="panel-heading">
                <h4 class="panel-title text-white">Keuangan</h4>
            </div>
            <div class="panel-body">
                <a href="{{url('/pembagianKeuangan')}}">
                    <?php if ($statusKeuangan == $jumlahrowKeuangan) { ?>
                        <h2>
                            <i class="mdi mdi-checkbox-marked-circle-outline text-success"></i>
                        </h2>

                    <?php
                    } else { ?>
                        <h2>
                            <i class="mdi mdi-timelapse text-danger"></i>
                        </h2>
                    <?php
                    } ?>
                    <h4>Juz ke {{$jus_ke1Keuangan}} - {{$jus_ke2Keuangan}}</h4>
                    <p class="text-muted"><b><?php echo date('l, d-m-Y'); ?></b></p>
                    <div class="progress">
                        <div class="progress-bar progress-bar-info progress-bar-striped active" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: <?php $Keuanganprogres = $statusKeuangan / $jumlahrowKeuangan * 100;
                                                                                                                                                                                            echo $Keuanganprogres ?>%">
                            <span class="sr-only">60% Complete</span>
                        </div>
                    </div>
            </div>
            </a>
        </div>
    </div>
    <div class="col-sm-4">
        <div class="panel panel-dark text-center">
            <div class="panel-heading">
                <h4 class="panel-title text-white">Distribusi</h4>
            </div>
            <div class="panel-body">
                <a href="{{url('/pembagianDistribusi')}}">
                    <?php if ($statusDistribusi == $jumlahrowDistribusi) { ?>
                        <h2>
                            <i class="mdi mdi-checkbox-marked-circle-outline text-success"></i>
                        </h2>

                    <?php
                    } else { ?>
                        <h2>
                            <i class="mdi mdi-timelapse text-danger"></i>
                        </h2>
                    <?php
                    } ?>
                    <h4>Juz ke {{$jus_ke1Distribusi}} - {{$jus_ke4Distribusi}}</h4>
                    <p class="text-muted"><b><?php echo date('l, d-m-Y'); ?></b></p>
                    <div class="progress">
                        <div class="progress-bar progress-bar-info progress-bar-striped active" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: <?php $Distribusiprogres = $statusDistribusi / $jumlahrowDistribusi * 100;
                                                                                                                                                                                            echo $Distribusiprogres ?>%">
                            <span class="sr-only">60% Complete</span>
                        </div>
                    </div>
            </div>
            </a>
        </div>
    </div>

    <div class="col-sm-4">
        <div class="panel panel-dark text-center">
            <div class="panel-heading">
                <h4 class="panel-title">Pengembangan Perusahaan</h4>
            </div>
            <div class="panel-body">
                <a href="{{url('/pembagianPengembanganperusahaan')}}">
                    <?php if ($statusPengembanganperusahaan == $jumlahrowPengembanganperusahaan) { ?>
                        <h2>
                            <i class="mdi mdi-checkbox-marked-circle-outline text-success"></i>
                        </h2>

                    <?php
                    } else { ?>
                        <h2>
                            <i class="mdi mdi-timelapse text-danger"></i>
                        </h2>
                    <?php
                    } ?>
                    <h4>Juz ke {{$jus_ke1Pengembanganperusahaan}} - {{$jus_ke7Pengembanganperusahaan}}</h4>
                    <p class="text-muted"><b><?php echo date('l, d-m-Y'); ?></b></p>
                    <div class="progress">
                        <div class="progress-bar progress-bar-info progress-bar-striped active" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: <?php $Pengembanganperusahaanprogres = $statusPengembanganperusahaan / $jumlahrowPengembanganperusahaan * 100;
                                                                                                                                                                                            echo $Pengembanganperusahaanprogres ?>%">
                            <span class="sr-only">60% Complete</span>
                        </div>
                    </div>
            </div>
            </a>
        </div>
    </div>
    <div class="col-sm-4">
        <div class="panel panel-dark text-center">
            <div class="panel-heading">
                <h4 class="panel-title text-white">Pengendalian Teknik</h4>
            </div>
            <div class="panel-body">
                <a href="{{url('/pembagianPengendalian')}}">

                    <?php if ($statusPengendalian == $jumlahrowPengendalian) { ?>
                        <h2>
                            <i class="mdi mdi-checkbox-marked-circle-outline text-success"></i>
                        </h2>
                    <?php
                    } else { ?>
                        <h2>
                            <i class="mdi mdi-timelapse text-danger"></i>
                        </h2>
                    <?php
                    } ?>

                    <h4>Juz ke {{$jus_ke1Pengendalian}} - {{$jus_ke7Pengendalian}}</h4>
                    <p class="text-muted"><b><?php echo date('l, d-m-Y'); ?></b></p>
                    <div class="progress">
                        <div class="progress-bar progress-bar-info progress-bar-striped active" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: <?php $Pengendalianprogres = $statusPengendalian / $jumlahrowPengendalian * 100;
                                                                                                                                                                                            echo $Pengendalianprogres ?>%">
                            <span class="sr-only">60% Complete</span>
                        </div>
                    </div>
            </div>
            </a>
        </div>
    </div>
    <div class="col-sm-4">
        <div class="panel panel-dark text-center">
            <div class="panel-heading">
                <h4 class="panel-title text-white">Pengadaan dan Logistik</h4>
            </div>
            <div class="panel-body">
                <a href="{{url('/pembagianPengadaan')}}">

                    <?php if ($statusPengadaan == $jumlahrowPengadaan) { ?>
                        <h2>
                            <i class="mdi mdi-checkbox-marked-circle-outline text-success"></i>
                        </h2>

                    <?php
                    } else { ?>
                        <h2>
                            <i class="mdi mdi-timelapse text-danger"></i>
                        </h2>
                    <?php
                    } ?>

                    <h4>Juz ke {{$jus_ke1Pengadaan}} - {{$jus_ke7Pengadaan}}</h4>
                    <p class="text-muted"><b><?php echo date('l, d-m-Y'); ?></b></p>
                    <div class="progress">
                        <div class="progress-bar progress-bar-info progress-bar-striped active" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: <?php $Pengadaanprogres = $statusPengadaan / $jumlahrowPengadaan * 100;
                                                                                                                                                                                            echo $Pengadaanprogres ?>%">
                            <span class="sr-only">60% Complete</span>
                        </div>
                    </div>
            </div>
            </a>
        </div>
    </div>

    <div class="col-sm-4">
        <div class="panel panel-dark text-center">
            <div class="panel-heading">
                <h4 class="panel-title text-white">Perencanaan Teknik</h4>
            </div>
            <div class="panel-body">
                <a href="{{url('/pembagianPerencanaan')}}">

                    <?php if ($statusPerencanaan == $jumlahrowPerencanaan) { ?>
                        <h2>
                            <i class="mdi mdi-checkbox-marked-circle-outline text-success"></i>
                        </h2>

                    <?php
                    } else { ?>
                        <h2>
                            <i class="mdi mdi-timelapse text-danger"></i>
                        </h2>
                    <?php
                    } ?>

                    <h4>Juz ke {{$jus_ke1Perencanaan}} - {{$jus_ke7Perencanaan}}</h4>
                    <p class="text-muted"><b><?php echo date('l, d-m-Y'); ?></b></p>
                    <div class="progress">
                        <div class="progress-bar progress-bar-info progress-bar-striped active" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: <?php $Perencanaanprogres = $statusPerencanaan / $jumlahrowPerencanaan * 100;
                                                                                                                                                                                            echo $Perencanaanprogres ?>%">
                            <span class="sr-only">60% Complete</span>
                        </div>
                    </div>
            </div>
            </a>
        </div>
    </div>
    <div class="col-sm-4">
        <div class="panel panel-dark text-center">
            <div class="panel-heading">
                <h4 class="panel-title text-white">Produksi</h4>
            </div>
            <div class="panel-body">
                <a href="{{url('/pembagianProduksi')}}">

                    <?php if ($statusProduksi == $jumlahrowProduksi) { ?>
                        <h2>
                            <i class="mdi mdi-checkbox-marked-circle-outline text-success"></i>
                        </h2>

                    <?php
                    } else { ?>
                        <h2>
                            <i class="mdi mdi-timelapse text-danger"></i>
                        </h2>
                    <?php
                    } ?>

                    <h4>Juz ke {{$jus_ke1Produksi}} - {{$jus_ke5Produksi}}</h4>
                    <p class="text-muted"><b><?php echo date('l, d-m-Y'); ?></b></p>
                    <div class="progress">
                        <div class="progress-bar progress-bar-info progress-bar-striped active" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: <?php $Produksiprogres = $statusProduksi / $jumlahrowProduksi * 100;
                                                                                                                                                                                            echo $Produksiprogres ?>%">
                            <span class="sr-only">60% Complete</span>
                        </div>
                    </div>
            </div>
            </a>
        </div>
    </div>
    <div class="col-sm-4">
        <div class="panel panel-dark text-center">
            <div class="panel-heading">
                <h4 class="panel-title">Satuan Pengawasan Intern</h4>
            </div>
            <div class="panel-body">
                <a href="{{url('/pembagianSPI')}}">

                    <?php if ($statusSPI == $jumlahrowSPI) { ?>
                        <h2>
                            <i class="mdi mdi-checkbox-marked-circle-outline text-success"></i>
                        </h2>

                    <?php
                    } else { ?>
                        <h2>
                            <i class="mdi mdi-timelapse text-danger"></i>
                        </h2>
                    <?php
                    } ?>

                    <h4>Juz ke {{$jus_ke1SPI}} - {{$jus_ke7SPI}}</h4>
                    <p class="text-muted"><b><?php echo date('l, d-m-Y'); ?></b></p>
                    <div class="progress">
                        <div class="progress-bar progress-bar-info progress-bar-striped active" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: <?php $SPIprogres = $statusSPI / $jumlahrowSPI * 100;
                                                                                                                                                                                            echo $SPIprogres ?>%">
                            <span class="sr-only">60% Complete</span>
                        </div>
                    </div>
            </div>
            </a>
        </div>
    </div>
    <div class="col-sm-4">
        <div class="panel panel-dark text-center">
            <div class="panel-heading">
                <h4 class="panel-title text-white">Sekertaris Perusahaan</h4>
            </div>
            <div class="panel-body">
                <a href="{{url('/pembagianSekper')}}">

                    <?php if ($statusSekper == $jumlahrowSekper) { ?>
                        <h2>
                            <i class="mdi mdi-checkbox-marked-circle-outline text-success"></i>
                        </h2>

                    <?php
                    } else { ?>
                        <h2>
                            <i class="mdi mdi-timelapse text-danger"></i>
                        </h2>
                    <?php
                    } ?>

                    <h4>Juz ke {{$jus_ke1Sekper}} - {{$jus_ke7Sekper}}</h4>
                    <p class="text-muted"><b><?php echo date('l, d-m-Y'); ?></b></p>
                    <div class="progress">
                        <div class="progress-bar progress-bar-info progress-bar-striped active" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: <?php $Sekperprogres = $statusSekper / $jumlahrowSekper * 100;
                                                                                                                                                                                            echo $Sekperprogres ?>%">
                            <span class="sr-only">60% Complete</span>
                        </div>
                    </div>
            </div>
            </a>
        </div>
    </div>
    <div class="col-sm-4">
        <div class="panel panel-dark text-center">
            <div class="panel-heading">
                <h4 class="panel-title text-white">SATPAM</h4>
            </div>
            <div class="panel-body">
                <a href="{{url('/pembagianSatpam')}}">

                    <?php if ($statusSatpam == $jumlahrowSatpam) { ?>
                        <h2>
                            <i class="mdi mdi-checkbox-marked-circle-outline text-success"></i>
                        </h2>
                    <?php
                    } else { ?>
                        <h2>
                            <i class="mdi mdi-timelapse text-danger"></i>
                        </h2>
                    <?php
                    } ?>

                    <h4>Juz ke {{$jus_ke1Satpam}} - {{$jus_ke3Satpam}}</h4>
                    <p class="text-muted"><b><?php echo date('l, d-m-Y'); ?></b></p>
                    <div class="progress">
                        <div class="progress-bar progress-bar-info progress-bar-striped active" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: <?php $Satpamprogres = $statusSatpam / $jumlahrowSatpam * 100;
                                                                                                                                                                                            echo $Satpamprogres ?>%">
                            <span class="sr-only">60% Complete</span>
                        </div>
                    </div>
            </div>
            </a>
        </div>
    </div>
    <div class="col-sm-4">
        <div class="panel panel-dark text-center">
            <div class="panel-heading">
                <h4 class="panel-title text-white">Office Boy</h4>
            </div>
            <div class="panel-body">
                <a href="{{url('/pembagianOfficeboy')}}">

                    <?php if ($statusOfficeboy == $jumlahrowOfficeboy) { ?>
                        <h2>
                            <i class="mdi mdi-checkbox-marked-circle-outline text-success"></i>
                        </h2>

                    <?php
                    } else { ?>
                        <h2>
                            <i class="mdi mdi-timelapse text-danger"></i>
                        </h2>
                    <?php
                    } ?>

                    <h4>Juz ke {{$jus_ke1Officeboy}} - {{$jus_ke7Officeboy}}</h4>
                    <p class="text-muted"><b><?php echo date('l, d-m-Y'); ?></b></p>
                    <div class="progress">
                        <div class="progress-bar progress-bar-info progress-bar-striped active" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: <?php $Officeboyprogres = $statusOfficeboy / $jumlahrowOfficeboy * 100; echo $Officeboyprogres ?>%">
                            <span class="sr-only">60% Complete</span>
                        </div>
                    </div>
            </div>
            </a>
        </div>
    </div>
</div>
<!--  -->

@endsection