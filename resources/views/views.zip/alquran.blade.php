@extends('master')

@section('konten')
</br>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">

            <div class="card">
                <div class="card-header">
                    BACAAN AL-Quran
                    <!-- <a href="{{ url('/pegawai/tambah') }}" class="float-right btn btn-sm btn-primary">Tambah</a> -->
                </div>
                </br>

                <div class="card-body">

                    @if(Session::has('sukses'))
                    <div class="alert alert-success">
                        {{ Session::get('sukses') }}
                    </div>
                    @endif

                    <div class="row">
                        <div class="col-md-3">
                            <form action="{{ url('/alquran/cari') }}" method="get" class="form-inline">

                                <input type="text" name="cari" value="<?php if (isset($_GET['cari'])) {
                                                                            echo $_GET['cari'];
                                                                        } ?>" class="form-control" placeholder="Cari Surat ke ...">
                                <input type="submit" class="btn btn-primary" value="Cari">

                            </form>
                        </div>
                    </div>
                    </br>

                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th width="1%">No</th>
                                <th>Surat Ke</th>
                                <th>Nama Surat</th>
                                <th>Ayat Ke</th>
                                <th>Bacaan</th>
                                <th>Juz ke</th>
                                <!-- <th width="15%" class="text-center">OPSI</th> -->
                            </tr>
                        </thead>

                        <tbody>

                            @php
                            $no = 1;
                            @endphp
                            @foreach($alquran as $a)
                            <tr>
                                <td>{{ $no++ }}</td>
                                <td>Surah {{$a->surat_ke}}</td>
                                <td>{{ $a->nama_surat }}</td>
                                <td>Ayat {{$a->ayat_ke}}</td>
                                <td <strong style="font-size: 25px;"></strong>{{$a->bacaan}}</td>
                                <td>Juz {{$a->jus_ke}}</td>
                                <!-- <td class="text-center">
                                    <a href="{{ url('/pegawai/edit/'.$a->id) }}" class="btn btn-sm btn-warning">Edit</a>
                                    <a href="{{ url('/pegawai/hapus/'.$a->id) }}"
                                        class="btn btn-sm btn-danger">Hapus</a>
                                </td> -->
                            </tr>
                            @endforeach

                        </tbody>
                    </table>
                    {{ $alquran->links() }}
                </div>
            </div>

        </div>
    </div>
</div>
@endsection