@extends('master')

@section('konten')
</br>
<div class="container">
    <div class="row justify-content-center">
        
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    Form Input Pembagian Pemasaran
                    <!-- <a href="{{ url('/pemasaran/tambah') }}" class="float-right btn btn-sm btn-primary">Tambah</a> -->
                </div>
                </br>

                <div class="card-body">

                    @if(Session::has('sukses'))
                    <div class="alert alert-success">
                        {{ Session::get('sukses') }}
                    </div>
                    @endif

                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th width="1%">No</th>
                                <th>ID</th>
                                <th>Juz</th>
                                <!-- <th>Status</th> -->
                                <th width="15%" class="text-center">OPSI</th>
                            </tr>
                        </thead>

                        <tbody>
                            @php
                            $no = 1;
                            @endphp
                            @foreach($pemasaran as $pemasaran)
                            <tr>
                                <td>{{ $no++ }}</td>
                                <td>{{$pemasaran->id}}</td>
                                <td>{{$pemasaran->jus_ke}}</td>
                                <!-- <td>{{$pemasaran->status}}</td> -->

                                <td class="text-center">
                                    <a href="{{ url('/pemasaran_edit'.$pemasaran->id) }}" class="btn btn-sm btn-warning">Edit</a>
                                    <!-- <a href="{{ url('/pemasaran/hapus/'.$pemasaran->id) }}" class="btn btn-sm btn-danger">Hapus</a> -->
                                </td>
                            </tr>
                            @endforeach

                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
</div>
@endsection