<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\HomeController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [LoginController::class, 'login'])->name('login');
Route::post('actionlogin', [LoginController::class, 'actionlogin'])->name('actionlogin');

Route::get('/register', [HomeController::class, 'register'])->name('register');

Route::get('home', [HomeController::class, 'index'])->name('home')->middleware('auth');
Route::get('actionlogout', [LoginController::class, 'actionlogout'])->name('actionlogout')->middleware('auth');

Route::get('/pegawai', [HomeController::class, 'pegawai'])->name('pegawai');
Route::POST('/simpan_pegawai', [HomeController::class, 'simpan_pegawai'])->name('simpan_pegawai');
Route::get('/edit_pegawai', [HomeController::class, 'edit_pegawai'])->name('edit_pegawai');
Route::POST('/update_pegawai', [HomeController::class, 'update_pegawai'])->name('update_pegawai');
Route::get('/pegawai/hapus/{id}', [HomeController::class, 'pegawai_hapus'])->name('pegawai_hapus');

Route::get('/kendaraan', [HomeController::class, 'kendaraan'])->name('kendaraan');
Route::POST('/simpan_kendaraan', [HomeController::class, 'simpan_kendaraan'])->name('simpan_kendaraan');
Route::get('/edit_kendaraan', [HomeController::class, 'edit_kendaraan'])->name('edit_kendaraan');
Route::POST('/update_kendaraan', [HomeController::class, 'update_kendaraan'])->name('update_kendaraan');
Route::get('/kendaraan/hapus/{id}', [HomeController::class, 'kendaraan_hapus'])->name('kendaraan_hapus');

Route::get('/peminjaman', [HomeController::class, 'peminjaman'])->name('peminjaman');
Route::POST('/simpan_peminjaman', [HomeController::class, 'simpan_peminjaman'])->name('simpan_peminjaman');
Route::get('/edit_peminjaman', [HomeController::class, 'edit_peminjaman'])->name('edit_peminjaman');
Route::POST('/update_peminjaman', [HomeController::class, 'update_peminjaman'])->name('update_peminjaman');
Route::get('/peminjaman/hapus/{id}', [HomeController::class, 'peminjaman_hapus'])->name('peminjaman_hapus');
Route::get('/edit_peminjaman_selesai', [HomeController::class, 'edit_peminjaman_selesai'])->name('edit_peminjaman_selesai');
Route::POST('/update_selesai', [HomeController::class, 'update_selesai'])->name('update_selesai');
Route::POST('/update_terima', [HomeController::class, 'update_terima'])->name('update_terima');

Route::get('/pengajuan', [HomeController::class, 'pengajuan'])->name('pengajuan');
Route::POST('/simpan_pengajuan', [HomeController::class, 'simpan_pengajuan'])->name('simpan_pengajuan');
Route::get('/edit_pengajuan', [HomeController::class, 'edit_pengajuan'])->name('edit_pengajuan');
Route::POST('/update_pengajuan', [HomeController::class, 'update_pengajuan'])->name('update_pengajuan');
Route::get('/pengajuan/hapus/{id}', [HomeController::class, 'pengajuan_hapus'])->name('pengajuan_hapus');
Route::get('/edit_terima', [HomeController::class, 'edit_terima'])->name('edit_terima');

Route::get('/surat_jalan{id}', [HomeController::class, 'surat_jalan'])->name('surat_jalan');
Route::get('/detail_peminjaman{id}', [HomeController::class, 'detail_peminjaman'])->name('detail_peminjaman');

Route::get('/tamu', [HomeController::class, 'tamu'])->name('tamu');
Route::POST('/simpan_tamu', [HomeController::class, 'simpan_tamu'])->name('simpan_tamu');
Route::get('/edit_tamu', [HomeController::class, 'edit_tamu'])->name('edit_tamu');
Route::POST('/update_tamu', [HomeController::class, 'update_tamu'])->name('update_tamu');
Route::get('/tamu/hapus/{id}', [HomeController::class, 'tamu_hapus'])->name('tamu_hapus');
Route::get('/tamu/keluar/{id}', [HomeController::class, 'tamu_keluar'])->name('tamu_keluar');
Route::get('/detail_tamu{id}', [HomeController::class, 'detail_tamu'])->name('detail_tamu');
Route::POST('/tambah_ajax', [HomeController::class, 'tambah_ajax'])->name('tambah_ajax');
Route::get('/tamu_tambah', [HomeController::class, 'tamu_tambah'])->name('tamu_tambah');



// Route::get('/inventaris', [HomeController::class, 'inventaris'])->name('inventaris');
// Route::get('/inventaris/export_excel', [HomeController::class, 'export_excel'])->name('export_excel');
// Route::POST('/simpan_inventaris', [HomeController::class,'simpan_inventaris'])->name('simpan_inventaris');
// Route::get('/edit_inventaris', [HomeController::class, 'edit_inventaris'])->name('edit_inventaris');
// Route::POST('/update_inventaris', [HomeController::class, 'update_inventaris'])->name('update_inventaris');
// Route::get('/inventaris/hapus/{id}', [HomeController::class, 'inventaris_hapus'])->name('inventaris_hapus');

// Route::get('/handphone', [HomeController::class, 'handphone'])->name('handphone');
// Route::POST('/simpan_handphone', [HomeController::class, 'simpan_handphone'])->name('simpan_handphone');
// Route::get('/edit_handphone', [HomeController::class, 'edit_handphone'])->name('edit_handphone');
// Route::POST('/update_handphone', [HomeController::class, 'update_handphone'])->name('update_handphone');
// Route::get('/handphone/hapus/{id}', [HomeController::class, 'handphone_hapus'])->name('handphone_hapus');


// Route::get('/maintenance', [HomeController::class, 'maintenance'])->name('maintenance');
// Route::get('/maintenance_coba', [HomeController::class, 'maintenance_coba'])->name('maintenance_coba');
// Route::POST('/tambah_coba', [HomeController::class, 'tambah_coba'])->name('tambah_coba');
// Route::get('/maintenance/export_maintenance', [HomeController::class, 'export_maintenance'])->name('export_maintenance');

// Route::POST('/simpan_maintenance', [HomeController::class, 'simpan_maintenance'])->name('simpan_maintenance');
// Route::get('/edit_maintenance', [HomeController::class, 'edit_maintenance'])->name('edit_maintenance');
// Route::POST('/update_maintenance', [HomeController::class, 'update_maintenance'])->name('update_maintenance');
// Route::get('/maintenance/hapus/{id}', [HomeController::class, 'maintenance_hapus'])->name('maintenance_hapus');
// Route::get('/maintenance_tambah', [HomeController::class, 'maintenance_tambah'])->name('maintenance_tambah');
// Route::POST('/action_maintenance', [HomeController::class, 'action_maintenance'])->name('action_maintenance');
// Route::get('/detail_maintenance', [HomeController::class, 'detail_maintenance'])->name('detail_maintenance');

