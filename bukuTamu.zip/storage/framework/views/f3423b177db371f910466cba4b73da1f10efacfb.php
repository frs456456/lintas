

<?php $__env->startSection('konten'); ?>
</br>
<div class="container">
    <div class="row justify-content-center">

        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    Form Input Pembagian
                    <!-- <a href="<?php echo e(url('/pemasaran/tambah')); ?>" class="float-right btn btn-sm btn-primary">Tambah</a> -->
                </div>
                </br>

                <div class="card-body">

                    <?php if(Session::has('sukses')): ?>
                    <div class="alert alert-success">
                        <?php echo e(Session::get('sukses')); ?>

                    </div>
                    <?php endif; ?>

                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th width="1%">No</th>
                                <th>ID</th>
                                <th>Juz</th>
                                <!-- <th>Keuangan</th> -->
                                <th width="15%" class="text-center">OPSI</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php
                            $no = 1;
                            ?>
                            <?php $__currentLoopData = $keuangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keuangan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($no++); ?></td>
                                <td><?php echo e($keuangan->id); ?></td>
                                <td><?php echo e($keuangan->jus_ke); ?></td>
                                <!-- <td><?php echo e($keuangan->status); ?></td> -->

                                <td class="text-center">
                                    <a href="<?php echo e(url('/keuangan_edit'.$keuangan->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                                    <!-- <a href="<?php echo e(url('/pemasaran/hapus/'.$keuangan->id)); ?>" class="btn btn-sm btn-danger">Hapus</a> -->
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tilawah_quran\resources\views/keuangan.blade.php ENDPATH**/ ?>