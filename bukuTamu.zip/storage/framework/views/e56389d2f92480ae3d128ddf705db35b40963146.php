

<?php $__env->startSection('konten'); ?>

<?php

use Illuminate\Support\Facades\Auth;

$roleadmin = Auth::user()->role;
?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">

                </div>

                <div class="card-body">

                    <?php if(Session::has('sukses')): ?>
                    <div class="alert alert-success">
                        <?php echo e(Session::get('sukses')); ?>

                    </div>
                    <?php endif; ?>

                    <div class="row">
                        <div class="col-md-12">
                            <div class="panel panel-primary">
                                <div class="panel-heading">
                                    <h3 class="panel-title">Data Kendaraan</h3>
                                    <button type="button" class="btn btn-success btn-primary waves-effect waves-light" data-toggle="modal" data-target="#myModal"><i class="fa fa-plus"></i>
                                        Tambah</button>
                                </div>

                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-xs-12">
                                            <div class="table-responsive">
                                                <table id="datatable-buttons" class="table table-striped table-bordered">
                                                    <thead>
                                                        <tr>
                                                            <th width="1%">No</th>
                                                            <th>Jenis Kendaraan</th>
                                                            <th>Nomor Polisi</th>
                                                            <th>Nomor Mesin</th>
                                                            <th>Nomor Rangka</th>
                                                            <th>Merek</th>
                                                            <th>Warna</th>
                                                            <th>option</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                        $no = 1;
                                                        ?>
                                                        <?php $__currentLoopData = $kendaraan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kendaraan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($no++); ?></td>
                                                            <td><?php echo e($kendaraan->jenisKendaraan); ?></td>
                                                            <td><?php echo e($kendaraan->noPolisi); ?></td>
                                                            <td><?php echo e($kendaraan->noMesin); ?></td>
                                                            <td><?php echo e($kendaraan->noRangka); ?></td>
                                                            <td><?php echo e($kendaraan->merek); ?></td>
                                                            <td><?php echo e($kendaraan->warna); ?></td>

                                                            <td class="text-center">
                                                                <button type="button" class="btn btn-xs btn-success edit_kendaraan" data-id="<?php echo e($kendaraan->id); ?>"><i class="fa fa-pencil"></i></button>

                                                                <a href="<?php echo e(url('/kendaraan/hapus/'.$kendaraan->id)); ?>" class="btn btn-xs btn-danger" onclick="return confirm('Yakin akan hapus data ??')"><i class="fa fa-trash"></i></a>

                                                            </td>
                                                        </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>

                                                </table>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> <!-- End row -->
                </div>
            </div>

        </div>
    </div>
</div>


<!-- MODAL TAMBAH DATA -->
<!-- MODAL TAMBAH DATA -->
<div id="myModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h4 class="modal-title" id="myModalLabel">Tambah Data</h4>
            </div>
            <div class="modal-body">
                <form name="frm_add" id="frm_add" action="<?php echo e(route('simpan_kendaraan')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group"><label class="control-label">Jenis Kendaraan</label>
                        <div>
                            <select name="jenisKendaraan" id="jenisKendaraan" class="form-control">
                                <option value="">- Pilih Kendaraan</option>
                                <option value="roda dua">Roda Dua</option>
                                <option value="roda empat">Roda Empat</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group"><label class="control-label">Nomor Polisi</label>
                        <div><input type="text" name="noPolisi" placeholder="Nomor Polisi" class="form-control" required>
                        </div>
                    </div>
                    <div class="form-group"><label class="control-label">Nomor Mesin</label>
                        <div><input type="text" name="noMesin" placeholder="Nomor Mesin" class="form-control" required>
                        </div>
                    </div>
                    <div class="form-group"><label class="control-label">Nomor Rangka</label>
                        <div><input type="text" name="noRangka" placeholder="Nomor Rangka" class="form-control" required></div>
                    </div>
                    <div class="form-group"><label class="control-label">Merek</label>
                        <div><input type="text" name="merek" placeholder="Merek" class="form-control" required></div>
                    </div>
                    <div class="form-group"><label class="control-label">Warna</label>
                        <div><input type="text" name="warna" placeholder="warna" class="form-control" required></div>
                    </div>

                    <div class="form-group"><label class="control-label"></label>
                        <button type="button" class="btn btn-default waves-effect" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary waves-effect waves-light">Simpan</button>
                    </div>
                </form>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<!-- END MODAL TAMBAH DATA -->
<!-- END MODAL TAMBAH DATA -->

<!-- MODAL UBAH DATA -->
<!-- MODAL UBAH DATA -->

<div id="modal_edit" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h4 class="modal-title" id="myModalLabel">Ubah DATA</h4>
            </div>
            <div class="modal-body">
                <form name="frm_add" id="frm_add" action="<?php echo e(route('update_kendaraan')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group"><label class="control-label">Jenis Kendaraan</label>
                        <div><select name="jenisKendaraan" id="jenisKendaraan" class="form-control">
                                <option value="">- Pilih Kendaraan</option>
                                <option value="roda dua">Roda Dua</option>
                                <option value="roda empat">Roda Empat</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group"><label class="control-label">Nomor Polisi</label>
                        <div><input type="text" name="noPolisi" id="noPolisi" class="form-control" required></div>
                    </div>
                    <div class="form-group"><label class="control-label">Nomor Mesin</label>
                        <div><input type="text" name="noMesin" id="noMesin" class="form-control" required>
                        </div>
                    </div>
                    <div class="form-group"><label class="control-label">Nomor Rangka</label>
                        <div><input type="text" name="noRangka" id="noRangka" class="form-control" required>
                        </div>
                    </div>
                    <div class="form-group"><label class="control-label">Merek</label>
                        <div><input type="text" name="merek" id="merek" class="form-control" required></div>
                    </div>
                    <div class="form-group"><label class="control-label">Warna</label>
                        <div><input type="text" name="warna" id="warna" class="form-control" required></div>
                    </div>

                    <div class="modal-footer">
                    </div>

                    <input type="hidden" name="id" id="id" value="">
                    <div class="form-group"><label class="control-label"></label>
                        <button type="button" class="btn btn-default waves-effect" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary waves-effect waves-light">Ubah</button>
                    </div>
            </div>
            </form>
        </div>
    </div>
</div>
</div>
<!-- END MODAL UBAH DATA -->
<!-- END MODAL UBAH DATA -->


<script type="text/javascript" src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
<script>
    $(document).ready(function() {
        //edit data
        $('body').on('click', '.edit_kendaraan', function() {
            var id = $(this).attr('data-id');
            $.ajax({
                url: "<?php echo e(route('edit_kendaraan')); ?>?id=" + id,
                type: "GET",
                dataType: "JSON",
                success: function(data) {
                    $('#id').val(data.id);
                    // $('#jenisKendaraan').val(data.jenisKendaraan);
                    $('#jenisKendaraan option[value="' + data.jenisKendaraan + '"]').prop('selected', true);
                    $('#noPolisi').val(data.noPolisi);
                    $('#noMesin').val(data.noMesin);
                    $('#noRangka').val(data.noRangka);
                    $('#merek').val(data.merek);
                    $('#warna').val(data.warna);
                    $('#modal_edit').modal('show');
                }

            });
        });

    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bukuTamu\resources\views/kendaraan.blade.php ENDPATH**/ ?>