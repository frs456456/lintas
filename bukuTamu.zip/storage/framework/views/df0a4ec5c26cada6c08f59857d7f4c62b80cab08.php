

<?php $__env->startSection('konten'); ?>
<!-- Jumlah Ayat <?php echo e($jumlahjuskePemasaran); ?>

<?php echo e($pembagianPemasaran->links(('pagination::bootstrap-4'))); ?> -->
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                </div>
                <div class="card-body">

                    <?php if(Session::has('sukses')): ?>
                    <div class="alert alert-success">
                        <?php echo e(Session::get('sukses')); ?>

                    </div>
                    <?php endif; ?>

                    <div class="row">
                        <div class="col-md-12">
                            <div class="panel panel-primary">
                                <div class="panel-heading">
                                    <h3 class="panel-title">Data Pegawai</h3>
                                </div>
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-xs-12">
                                            <div class="table-responsive" style="height: 200px;overflow: scroll;">
                                                <table id="datatable-responsive" class="table table-striped dt-responsive nowrap" cellspacing="0" width="100%">
                                                    <thead>
                                                        <tr>
                                                            <th width="1%">No</th>
                                                            <th>Nama Pegawai</th>
                                                            <th>Divisi</th>
                                                            <th>Link Pembagian</th>
                                                            <th>Status</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                        $noIT = 1;
                                                        $no = 1;
                                                        ?>
                                                        <?php $__currentLoopData = $pegawaiPemasaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($no++); ?></td>
                                                            <td><?php echo e($p->name); ?></td>
                                                            <td><?php echo e($p->divisi); ?></td>
                                                            <td><a href="<?php echo e(url('/pembagianPemasaran?page=')); ?><?php echo e($noIT++); ?>">Pembagian</a></td>
                                                            <td><?php echo e($p->status); ?></td>
                                                        </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> <!-- End row -->

                    <br>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="panel panel-success">
                                <div class="panel-heading">
                                    <h3 class="panel-title text-white">Pembagian Tilawah</h3>
                                </div>
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-xs-12">

                                            <table class="table table-striped">
                                                <thead>
                                                    <tr>
                                                        <th width="1%">No</th>
                                                        <th>Nama Surat</th>
                                                        <th>Ayat Ke</th>
                                                        <th>Bacaan</th>
                                                        <th>Juz ke</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    $no = 1;
                                                    ?>
                                                    <?php $__currentLoopData = $pembagianPemasaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pembagianPemasaran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($no++); ?></td>
                                                        <td><?php echo e($pembagianPemasaran->nama_surat); ?></td>
                                                        <td>Ayat <?php echo e($pembagianPemasaran->ayat_ke); ?></td>
                                                        <td style="font-size: 25px; font-family:Scheherazade New;"><?php echo e($pembagianPemasaran->bacaan); ?></strong></td>
                                                        <td>Juz <?php echo e($pembagianPemasaran->jus_ke); ?></td>
                                                    </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> <!-- End row -->
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tilawah_quran\resources\views/pembagianPemasaran.blade.php ENDPATH**/ ?>