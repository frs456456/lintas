

<?php $__env->startSection('konten'); ?>

<?php

use Illuminate\Support\Facades\Auth;

$roleadmin = Auth::user()->role;
?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">

                </div>

                <div class="card-body">

                    <?php if(Session::has('sukses')): ?>
                    <div class="alert alert-success">
                        <?php echo e(Session::get('sukses')); ?>

                    </div>
                    <?php endif; ?>

                    <div class="row">
                        <div class="col-md-12">
                            <div class="panel panel-primary">
                                <div class="panel-heading">
                                    <h3 class="panel-title">Data Peminjaman Kendaraan</h3>
                                    <button type="button" class="btn btn-success btn-primary waves-effect waves-light tambah_pinjam" data-toggle="modal" data-target="#myModal"><i class="fa fa-plus"></i>
                                        Tambah</button>
                                </div>

                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-xs-12">
                                            <div class="table-responsive">
                                                <table id="datatable-buttons" class="table table-striped table-bordered">
                                                    <thead>
                                                        <tr>
                                                            <th width="1%">No</th>
                                                            <th>Tanggal</th>
                                                            <th>Nomor Formulir</th>
                                                            <th>Pegawai</th>
                                                            <th>Supir</th>
                                                            <th>Durasi</th>
                                                            <th>Keperluan</th>
                                                            <th>Status</th>
                                                            <th>Option</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                        $no = 1;
                                                        ?>
                                                        <?php $__currentLoopData = $peminjaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $peminjaman): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($no++); ?></td>
                                                            <td><?php echo e($peminjaman->tanggal); ?></td>
                                                            <td><?php echo e($peminjaman->noForm); ?></td>
                                                            <td><?php echo e($peminjaman->pegawai->nama); ?></td>
                                                            <td><?php echo e($peminjaman->namaSupir); ?></td>
                                                            <td><?php echo e($peminjaman->lamaPinjam); ?> Hari</td>
                                                            <td><?php echo e($peminjaman->keperluan); ?></td>
                                                            <td><?php if ($peminjaman->status == 1) { ?><button type="button" class="btn btn-warning btn-xs waves-effect waves-light">Diajukan</button>
                                                                <?php }
                                                                if ($peminjaman->status == 2) { ?>
                                                                    <button class="btn btn-primary btn-xs waves-effect waves-light">Proses</button>
                                                                <?php }
                                                                if ($peminjaman->status == 3) { ?>
                                                                    <button class="btn btn-success btn-xs waves-effect waves-light">Selesai</button>
                                                                <?php } ?>
                                                            </td>


                                                            <?php if ($peminjaman->status == 1 and is_null($peminjaman->kmAwal)) { ?>
                                                                <td class="text-center">
                                                                    <button type="button" class="btn btn-xs btn-success edit_peminjaman" data-id="<?php echo e($peminjaman->id); ?>"><i class="fa fa-pencil"></i> Ubah</button>

                                                                    <a href="<?php echo e(url('/peminjaman/hapus/'.$peminjaman->id)); ?>" class="btn btn-xs btn-danger" onclick="return confirm('Yakin akan hapus data ??')"><i class="fa fa-trash"> Hapus</i></a>
                                                                </td>
                                                            <?php }
                                                            if ($peminjaman->status == 2 and is_null($peminjaman->kmAwal)) { ?>
                                                                <td class="text-center">
                                                                    <a href="<?php echo e(url('/surat_jalan'.$peminjaman->id)); ?>" class=" btn btn-xs btn-primary"><i class="ti-printer"></i> Cetak</a>

                                                                    <button type="button" class="btn btn-xs btn-success edit_peminjaman_selesai" data-id="<?php echo e($peminjaman->id); ?>"><i class="ti-check"></i> Selesai</button>
                                                                </td>
                                                            <?php }
                                                            if ($peminjaman->status == 2 and !empty($peminjaman->kmAwal)) {
                                                            ?> <td class="text-center">
                                                                    <a href="<?php echo e(url('/surat_jalan'.$peminjaman->id)); ?>" class=" btn btn-xs btn-primary"><i class="ti-printer"></i> Cetak</a>
                                                                </td>
                                                            <?php
                                                            }
                                                            if ($peminjaman->status == 3) { ?>
                                                                <td class="text-center">
                                                                    <button class="btn btn-success btn-xs waves-effect waves-light">Selesai</button>
                                                                <?php } ?>
                                                                </td>
                                                        </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>

                                                </table>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> <!-- End row -->
                </div>
            </div>

        </div>
    </div>
</div>


<!-- MODAL TAMBAH DATA -->
<!-- MODAL TAMBAH DATA -->
<div id="myModal" class="modal fade" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h4 class="modal-title" id="myModalLabel">Tambah Data</h4>
            </div>
            <div class="modal-body">
                <form name="frm_add" id="frm_add" action="<?php echo e(route('simpan_peminjaman')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group"><label class="control-label">Tanggal Peminjaman</label>
                        <div>
                            <input type="date" name="tanggal" placeholder="Tanggal Peminjaman" class="form-control">
                        </div>
                    </div>
                    <div class="form-group"><label class="control-label">Nomor Formulir</label>
                        <div><input type="text" name="noForm" id="noForm_auto" placeholder="Nomor Formulir" class="form-control" required>
                        </div>
                    </div>
                    <div class="form-group"><label class="control-label">Pegawai</label>
                        <div><select name="id_pegawai" id="id_pegawai">
                                <option value="">- Pilih pegawai</option>
                                <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pegawai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($pegawai->id); ?>"><?php echo e($pegawai->nama); ?> || <?php echo e($pegawai->divisi); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group"><label class="control-label">Nama Supir</label>
                        <div><input type="text" name="namaSupir" placeholder="Nama Supir" class="form-control" required>
                        </div>
                    </div>
                    <div class="form-group"><label class="control-label">Lama Pinjam</label>
                        <div><input type="number" name="lamaPinjam" placeholder="Lama Peminjaman (Hari)" class="form-control" required></div>
                    </div>
                    <div class="form-group"><label class="control-label">Keperluan</label>
                        <div><textarea name="keperluan" id="" cols="30" rows="10" class="form-control"></textarea></div>
                    </div>

                    <div class="form-group"><label class="control-label"></label>
                        <button type="button" class="btn btn-default waves-effect" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary waves-effect waves-light">Simpan</button>
                    </div>
                </form>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<!-- END MODAL TAMBAH DATA -->
<!-- END MODAL TAMBAH DATA -->

<!-- MODAL UBAH DATA -->
<!-- MODAL UBAH DATA -->

<div id="modal_edit" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h4 class="modal-title" id="myModalLabel">Ubah DATA</h4>
            </div>
            <div class="modal-body">
                <form name="frm_add" id="frm_add" action="<?php echo e(route('update_peminjaman')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group"><label class="control-label">Tanggal Peminjaman</label>
                        <div>
                            <input type="date" name="tanggal" id="tanggal" class="form-control">
                        </div>
                    </div>
                    <div class="form-group"><label class="control-label">Nomor Formulir</label>
                        <div><input type="text" name="noForm" id="noForm" placeholder="Nomor Formulir" class="form-control" required>
                        </div>
                    </div>
                    <div class="form-group"><label class="control-label">Pegawai</label>
                        <div><select name="id_pegawai" id="id_pegawai" class="form-control">
                                <option value="">- Pilih pegawai</option>
                                <?php $__currentLoopData = $pegawaiedit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pegawai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($pegawai->id); ?>"><?php echo e($pegawai->nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group"><label class="control-label">Nama Supir</label>
                        <div><input type="text" name="namaSupir" id="namaSupir" placeholder="Nama Supir" class="form-control" required>
                        </div>
                    </div>
                    <div class="form-group"><label class="control-label">Lama Pinjam</label>
                        <div><input type="number" name="lamaPinjam" id="lamaPinjam" placeholder="Lama Peminjaman (Hari)" class="form-control" required></div>
                    </div>
                    <div class="form-group"><label class="control-label">Keperluan</label>
                        <div><textarea name="keperluan" id="keperluan" cols="30" rows="10" class="form-control"></textarea></div>
                    </div>

                    <div class="modal-footer">
                    </div>

                    <input type="hidden" name="id" id="id" value="">
                    <div class="form-group"><label class="control-label"></label>
                        <button type="button" class="btn btn-default waves-effect" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary waves-effect waves-light">Ubah</button>
                    </div>
            </div>
            </form>
        </div>
    </div>
</div>
<!-- END MODAL UBAH DATA -->
<!-- END MODAL UBAH DATA -->

<!-- MODAL SELESAI DATA -->
<!-- MODAL SELESAI DATA -->

<div id="modal_edit_selesai" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h4 class="modal-title" id="myModalLabel">Ubah DATA</h4>
            </div>

            <div class="modal-body">
                <form name="frm_add" id="frm_add" action="<?php echo e(route('update_selesai')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group"><label class="control-label">KM Awal</label>
                        <div><input type="number" name="kmAwal" id="kmAwal" placeholder="Km Awal" class="form-control" required>
                        </div>
                    </div>
                    <div class="form-froup"><label class="control-label">Lampiran Kilometer Awal</label>
                        <div>
                            <input type="file" name="foto_kmawal" id="foto_kmawal" class="form-control">
                        </div>
                        <br>
                        <div class="form-group"><label class="control-label">KM Akhir</label>
                            <div><input type="number" name="kmAkhir" id="kmAkhir" placeholder="Km Akhir" class="form-control" required>
                            </div>
                        </div>
                        <div class="form-froup"><label class="control-label">Lampiran Kilometer Akhir</label>
                            <div>
                                <input type="file" name="foto_kmakhir" id="foto_kmakhir" class="form-control" accept="image/*" capture>
                            </div>



                            <div class="modal-footer">
                            </div>
                            <input type="hidden" name="id_selesai" id="id_selesai" value="">
                            <input type="hidden" name="id_kendaraan_edit" id="id_kendaraan_edit" value="">
                            <div class="form-group"><label class="control-label"></label>
                                <button type="button" class="btn btn-default waves-effect" data-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary waves-effect waves-light">Ubah</button>
                            </div>
                        </div>
                </form>
            </div>
        </div>
    </div>
    <!-- END MODAL SELESAI DATA -->
    <!-- END MODAL SELESAI DATA -->

    <link rel="stylesheet" href="">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.8/css/select2.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.8/js/select2.min.js"></script>
    <script>
        $("#id_pegawai").select2({
            width: '100%'
        });

        $(".id_pegawai").select2({
            width: '100%'
        });

        $('#noForm_auto').val('SEKPER/14.07.22/__');

        $("#id_pegawai").val();

        $("#id_pegawai option:selected").text();

        $("#id_kendaraan").select2({
            width: '100%'
        });
    </script>
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
    <script>
        $(document).ready(function() {
            //edit data
            $('body').on('click', '.edit_peminjaman', function() {
                var id = $(this).attr('data-id');
                $.ajax({
                    url: "<?php echo e(route('edit_peminjaman')); ?>?id=" + id,
                    type: "GET",
                    dataType: "JSON",
                    success: function(data) {
                        $('#id').val(data.id);
                        $('#tanggal').val(data.tanggal);
                        $('#noForm').val(data.noForm);
                        $('#id_pegawai option[value="' + data.id_pegawai + '"]').prop(
                            'selected', true);
                        $('#namaSupir').val(data.namaSupir);
                        $('#lamaPinjam').val(data.lamaPinjam);
                        $('#keperluan').val(data.keperluan);
                        $('#modal_edit').modal('show');
                    }

                });
            });

            $('body').on('click', '.edit_peminjaman_selesai', function() {
                var id = $(this).attr('data-id');
                $.ajax({
                    url: "<?php echo e(route('edit_peminjaman_selesai')); ?>?id=" + id,
                    type: "GET",
                    dataType: "JSON",
                    success: function(data) {
                        $('#id_selesai').val(data.id);
                        $('#id_kendaraan_edit').val(data.id_kendaraan);
                        $('#kmAwal').val(data.kmAwal);
                        $('#kmAkhir').val(data.kmAkhir);
                        $('#modal_edit_selesai').modal('show');
                    }

                });
            });

        });
    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bukuTamu\resources\views/peminjaman.blade.php ENDPATH**/ ?>