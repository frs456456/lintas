

<?php $__env->startSection('konten'); ?>

<?php

use Illuminate\Support\Facades\Auth;

$roleadmin = Auth::user()->role;
?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">

                </div>

                <div class="card-body">

                    <?php if(Session::has('sukses')): ?>
                    <div class="alert alert-success">
                        <?php echo e(Session::get('sukses')); ?>

                    </div>
                    <?php endif; ?>

                    <div class="row">
                        <div class="col-md-12">
                            <div class="panel panel-primary">
                                <div class="panel-heading">
                                    <h3 class="panel-title">Data Pengajuan Peminjaman</h3>
                                </div>

                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-xs-12">
                                            <div class="table-responsive">
                                                <table id="datatable-buttons" class="table table-striped table-bordered">
                                                    <thead>
                                                        <tr>
                                                            <th width="1%">No</th>
                                                            <th>Tanggal</th>
                                                            <th>Nomor Formulir</th>
                                                            <th>Pegawai</th>
                                                            <th>Supir</th>
                                                            <th>Durasi</th>
                                                            <th>Keperluan</th>
                                                            <th>Kendaraan</th>
                                                            <th>Status</th>
                                                            <th>Option</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                        $no = 1;
                                                        ?>
                                                        <?php $__currentLoopData = $pengajuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengajuan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if ($pengajuan->status == 2 or $pengajuan->status == 1) { ?>
                                                            <tr style="background-color:bisque ;">
                                                                <td><?php echo e($no++); ?></td>
                                                                <td><?php echo e($pengajuan->tanggal); ?></td>
                                                                <td><?php echo e($pengajuan->noForm); ?></td>
                                                                <td><?php echo e($pengajuan->pegawai->nama); ?></td>
                                                                <td><?php echo e($pengajuan->namaSupir); ?></td>
                                                                <td><?php echo e($pengajuan->lamaPinjam); ?> Hari</td>
                                                                <td><?php echo e($pengajuan->keperluan); ?></td>
                                                                <td><?php echo e($pengajuan->kendaraan->merek); ?></td>
                                                                <td><?php if ($pengajuan->status == 1) { ?><button type="button" class="btn btn-warning btn-xs waves-effect waves-light">Diajukan</button>
                                                                    <?php }
                                                                    if ($pengajuan->status == 2) { ?>
                                                                        <button class="btn btn-danger btn-xs waves-effect waves-light">Proses</button>
                                                                    <?php }
                                                                    if ($pengajuan->status == 3) { ?>
                                                                        <button class="btn btn-success btn-xs waves-effect waves-light">Selesai</button>
                                                                    <?php } ?>
                                                                </td>

                                                                <td class="text-center">

                                                                    <?php if ($pengajuan->status == 1) { ?> <button type="button" class="btn btn-xs btn-warning edit_pengajuan" data-id="<?php echo e($pengajuan->id); ?>"><i class="ti-loop"></i></button>

                                                                        <a href="<?php echo e(url('/pengajuan/hapus/'.$pengajuan->id)); ?>" class="btn btn-xs btn-danger" onclick="return confirm('Yakin akan hapus data ??')"><i class="ti-close"></i></a>
                                                                    <?php }
                                                                    if ($pengajuan->status == 2 and is_null($pengajuan->kmAwal)) { ?>

                                                                    <?php }
                                                                    if ($pengajuan->status == 2 and !empty($pengajuan->kmAwal)) { ?>
                                                                        <button type="button" class="btn btn-xs btn-success edit_terima" data-id="<?php echo e($pengajuan->id); ?>"><i class="ti-check-box"></i>Terima</button>
                                                                    <?php
                                                                    }
                                                                    if ($pengajuan->status == 3) { ?>
                                                                        <a href="<?php echo e(url('/detail_peminjaman'.$pengajuan->id)); ?>" class=" btn btn-xs btn-primary"><i class="ti-eye"></i> Detail</a>
                                                                    <?php } ?>


                                                                </td>
                                                            </tr>
                                                        <?php } else { ?>
                                                            <tr>
                                                                <td><?php echo e($no++); ?></td>
                                                                <td><?php echo e($pengajuan->tanggal); ?></td>
                                                                <td><?php echo e($pengajuan->noForm); ?></td>
                                                                <td><?php echo e($pengajuan->pegawai->nama); ?></td>
                                                                <td><?php echo e($pengajuan->namaSupir); ?></td>
                                                                <td><?php echo e($pengajuan->lamaPinjam); ?> Hari</td>
                                                                <td><?php echo e($pengajuan->keperluan); ?></td>
                                                                <td><?php echo e($pengajuan->kendaraan->merek); ?></td>
                                                                <td><?php if ($pengajuan->status == 1) { ?><button type="button" class="btn btn-warning btn-xs waves-effect waves-light">Diajukan</button>
                                                                    <?php }
                                                                    if ($pengajuan->status == 2) { ?>
                                                                        <button class="btn btn-danger btn-xs waves-effect waves-light">Proses</button>
                                                                    <?php }
                                                                    if ($pengajuan->status == 3) { ?>
                                                                        <button class="btn btn-success btn-xs waves-effect waves-light">Selesai</button>
                                                                    <?php } ?>
                                                                </td>

                                                                <td class="text-center">

                                                                    <?php if ($pengajuan->status == 1) { ?> <button type="button" class="btn btn-xs btn-warning edit_pengajuan" data-id="<?php echo e($pengajuan->id); ?>"><i class="ti-loop"></i></button>

                                                                        <a href="<?php echo e(url('/pengajuan/hapus/'.$pengajuan->id)); ?>" class="btn btn-xs btn-danger" onclick="return confirm('Yakin akan hapus data ??')"><i class="ti-close"></i></a>
                                                                    <?php }
                                                                    if ($pengajuan->status == 2 and is_null($pengajuan->kmAwal)) { ?>

                                                                    <?php }
                                                                    if ($pengajuan->status == 2 and !empty($pengajuan->kmAwal)) { ?>
                                                                        <button type="button" class="btn btn-xs btn-success edit_terima" data-id="<?php echo e($pengajuan->id); ?>"><i class="ti-check-box"></i>Terima</button>
                                                                    <?php
                                                                    }
                                                                    if ($pengajuan->status == 3) { ?>
                                                                        <a href="<?php echo e(url('/detail_peminjaman'.$pengajuan->id)); ?>" class=" btn btn-xs btn-primary"><i class="ti-eye"></i> Detail</a>
                                                                    <?php } ?>


                                                                </td>
                                                            </tr>
                                                        <?php
                                                        } ?>

                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>

                                                </table>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> <!-- End row -->
                </div>
            </div>

        </div>
    </div>
</div>


<!-- MODAL UBAH DATA -->
<!-- MODAL UBAH DATA -->

<div id="modal_edit" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h4 class="modal-title" id="myModalLabel">Terima Pengajuan Peminjaman</h4>
            </div>
            <div class="modal-body">
                <form name="frm_add" id="frm_add" action="<?php echo e(route('update_pengajuan')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group"><label class="control-label">Kendaraan</label>
                        <div><select name="id_kendaraan" id="id_kendaraan" class="form-control">
                                <option value="">- Pilih Kendaraan</option>
                                <?php $__currentLoopData = $kendaraan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kendaraan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($kendaraan->id); ?>"><?php echo e($kendaraan->noPolisi); ?> || <?php echo e($kendaraan->merek); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="modal-footer">
                    </div>

                    <input type="hidden" name="id" id="id" value="">
                    <div class="form-group"><label class="control-label"></label>
                        <button type="button" class="btn btn-default waves-effect" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary waves-effect waves-light">SIMPAN</button>
                    </div>
            </div>
            </form>
        </div>
    </div>
</div>
</div>
<!-- END MODAL UBAH DATA -->
<!-- END MODAL UBAH DATA -->

<!-- MODAL EDIT TERIMA -->
<!-- MODAL EDIT TERIMA -->

<div id="modal_edit_terima" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h4 class="modal-title" id="myModalLabel">Terima Kendaraan</h4>
            </div>
            <div class="modal-body">
                <form name="frm_add" id="frm_add" action="<?php echo e(route('update_terima')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group"><label class="control-label">Tanggal Kembali</label>
                        <div><input type="date" name="tgl_kembali" id="tgl_kembali" class="form-control">
                        </div>
                    </div>
                    <div>
                        <div class="form-group"><label class="control-label">Kesesuaian Pengembalian</label></div>
                        <select name="terlambat" id="terlambat" class="form-control">
                            <option value="">Pilih</option>
                            <option value="terlambat">Terlambat</option>
                            <Option value="tidak terlambat">Tidak Terlambat</Option>
                        </select>
                    </div>

                    <div class="modal-footer">
                    </div>

                    <input type="hidden" name="id_terima" id="id_terima" value="">
                    <div class="form-group"><label class="control-label"></label>
                        <button type="button" class="btn btn-default waves-effect" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary waves-effect waves-light">SIMPAN</button>
                    </div>
            </div>
            </form>
        </div>
    </div>
</div>
</div>
<!-- END MODAL EDIT TERIMA -->
<!-- END MODAL EDIT TERIMA -->

<link rel="stylesheet" href="">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.8/css/select2.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.8/js/select2.min.js"></script>
<script>
    $("#id_pegawai").select2({
        width: '100%'
    });

    $(".id_pegawai").select2({
        width: '100%'
    });

    $("#id_pegawai").val();

    $("#id_pegawai option:selected").text();

    $("#id_kendaraan").select2({
        width: '100%'
    });
</script>
<script type="text/javascript" src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
<script>
    $(document).ready(function() {
        //edit data
        $('body').on('click', '.edit_pengajuan', function() {
            var id = $(this).attr('data-id');
            $.ajax({
                url: "<?php echo e(route('edit_pengajuan')); ?>?id=" + id,
                type: "GET",
                dataType: "JSON",
                success: function(data) {
                    $('#id').val(data.id);
                    $('#id_kendaraan').val(data.id_kendaraan);
                    $('#modal_edit').modal('show');
                }

            });
        });

        $('body').on('click', '.edit_terima', function() {
            var id = $(this).attr('data-id');
            $.ajax({
                url: "<?php echo e(route('edit_terima')); ?>?id=" + id,
                type: "GET",
                dataType: "JSON",
                success: function(data) {
                    $('#id_terima').val(data.id);
                    $('#modal_edit_terima').modal('show');
                }

            });
        });

    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bukuTamu\resources\views/pengajuan.blade.php ENDPATH**/ ?>