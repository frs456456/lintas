

<?php $__env->startSection('konten'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">

            <div class="card">
                <div class="card-header">
                    Pengaturan

                    <a href="<?php echo e(url('/pengaturan')); ?>" class="float-right btn btn-sm btn-primary">Kembali</a>
                </div>
                <div class="card-body">

                    <form method="post" action="<?php echo e(url('/pengaturan/aksi')); ?>">

                        <?php echo csrf_field(); ?>


                        <div class="form-group">

                            <label>Tanggal Khataman</label>
                            <input type="date" name="tanggal" class="form-control">

                            <?php if($errors->has('tanggal')): ?>
                            <span class="text-danger">
                                <strong><?php echo e($errors->first('tanggal')); ?></strong>
                            </span>
                            <?php endif; ?>

                        </div>

                        <div class="form-group">

                            <label>Tanggal Khataman</label>
                            <input type="date" name="tanggal" class="form-control">

                            <?php if($errors->has('tanggal')): ?>
                            <span class="text-danger">
                                <strong><?php echo e($errors->first('tanggal')); ?></strong>
                            </span>
                            <?php endif; ?>

                        </div>

                        <input type="submit" class="btn btn-primary" value="Simpan">

                    </form>

                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tilawah_quran\resources\views/pengaturan.blade.php ENDPATH**/ ?>