<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Khatam Quran - Tirta Asasta</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Admin Dashboard" name="description" />
    <meta content="ThemeDesign" name="author" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="shortcut icon" href="assets/images/favicon.ico">

    <!-- DataTables -->
    <link href="assets/plugins/datatables/jquery.dataTables.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/plugins/datatables/responsive.bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/plugins/datatables/dataTables.bootstrap.min.css" rel="stylesheet" type="text/css" />

    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet" type="text/css">
    <link href="assets/css/icons.css" rel="stylesheet" type="text/css">
    <link href="assets/css/style.css" rel="stylesheet" type="text/css">\

    <!-- FONT ARABIC -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Scheherazade+New&display=swap" rel="stylesheet">

    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>


<body class="fixed-left">

    <!-- Begin page -->
    <div id="wrapper">

        <!-- Top Bar Start -->
        <div class="topbar">
            <!-- LOGO -->
            <div class="topbar-left">
                <div class="text-center">
                    <center>
                        <img src="<?php echo e(('img/logopt.png')); ?>" width="110" class="logo">
                    </center>
                    <h4 class="text-white"></h4>
                </div>
            </div>
            <!-- Button mobile view to collapse sidebar menu -->
            <div class="navbar navbar-default" role="navigation">
                <div class="container">
                    <div class="">
                        <div class="pull-left">
                            <button type="button" class="button-menu-mobile open-left waves-effect waves-light">
                                <i class="ion-navicon"></i>
                            </button>
                            <span class="clearfix"></span>
                        </div>
                        <form class="navbar-form pull-left" role="search">
                            <div class="form-group">
                                <input type="text" class="form-control search-bar" placeholder="Search...">
                            </div>
                            <button type="submit" class="btn btn-search"><i class="fa fa-search"></i></button>
                        </form>

                        <ul class="nav navbar-nav navbar-right pull-right">

                            <li class="hidden-xs">
                                <a href="#" id="btn-fullscreen" class="waves-effect waves-light"><i class="fa fa-crosshairs"></i></a>
                            </li>
                            <li class="dropdown">
                                <a href="" class="dropdown-toggle profile waves-effect waves-light" data-toggle="dropdown" aria-expanded="true"><i class="fa fa-user"></i></a>
                                <ul class="dropdown-menu">
                                    <!-- <li><a href="javascript:void(0)"> Profile</a></li>
                                    <li><a href="javascript:void(0)"><span class="badge badge-success pull-right">5</span> Settings </a></li>
                                    <li><a href="javascript:void(0)"> Lock screen</a></li>
                                    <li class="divider"></li> -->
                                    <li><a href="<?php echo e(route('actionlogout')); ?>"> Logout</a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                    <!--/.nav-collapse -->
                </div>
            </div>
        </div>
        <!-- Top Bar End -->


        <!-- ========== Left Sidebar Start ========== -->

        <div class=" left side-menu">
            <div class="sidebar-inner slimscrollleft">
                <!-- <div class="user-details">

                    <div class="user-info">
                        <div class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><?php echo e(Auth::user()->name); ?></a>
                            <ul class="dropdown-menu">
                                <li><a href="javascript:void(0)"> Profile</a></li>
                                <li><a href="javascript:void(0)"> Settings</a></li>
                                <li><a href="javascript:void(0)"> Lock screen</a></li>
                                <li class="divider"></li>
                                <li><a href="javascript:void(0)"> Logout</a></li>
                            </ul>
                        </div>

                        <p class="text-muted m-0"><i class="fa fa-dot-circle-o text-success"></i> Online</p>
                    </div>
                </div> -->
                <!--- Divider -->
                <div id="sidebar-menu">
                    <ul>
                        <li>
                            <a href="<?php echo e(url('/home')); ?>" class="waves-effect"><i class="ti-home"></i><span> Dashboard </span></a>
                        </li>

                        <li>
                            <a href="<?php echo e(url('/alquran')); ?>" class="waves-effect"><i class="ti-book"></i><span> Al-Quran </span></a>
                        </li>

                        <li class="has_sub">
                            <a href="javascript:void(0);" class="waves-effect"><i class="ti-files"></i> <span> Pembagian Tilawah </span> <span class="pull-right"><i class="mdi mdi-plus"></i></span></a>
                            <ul class="list-unstyled">
                                <li><a href="<?php echo e(url('/pembagianIT')); ?>">Teknologi Informasi</a></li>
                                <li><a href="<?php echo e(url('/pembagianPemasaran')); ?>">Pemasaran</a></li>
                                <li><a href="<?php echo e(url('/pembagianSDM')); ?>">SDM</a></li>
                                <li><a href="<?php echo e(url('/pembagianKeuangan')); ?>">Keuangan</a></li>
                                <li><a href="<?php echo e(url('/pembagianDistribusi')); ?>">Distribusi</a></li>
                                <li><a href="<?php echo e(url('/pembagianPengembanganperusahaan')); ?>">Pengembangan Perusahaan</a></li>
                                <li><a href="<?php echo e(url('/pembagianPengendalian')); ?>">Pengendalian Teknik</a></li>
                                <li><a href="<?php echo e(url('/pembagianPengadaan')); ?>">Pengadaan dan Logistik</a></li>
                                <li><a href="<?php echo e(url('/pembagianPerencanaan')); ?>">Perencanaan Teknik</a></li>
                                <li><a href="<?php echo e(url('/pembagianProduksi')); ?>">Produksi</a></li>
                                <li><a href="<?php echo e(url('/pembagianSPI')); ?>">Satuan Pengawasan Intern</a></li>
                                <li><a href="<?php echo e(url('/pembagianSekper')); ?>">Sekertaris Perusahaan</a></li>
                                <li><a href="<?php echo e(url('/pembagianSatpam')); ?>">Satpam</a></li>
                                <li><a href="<?php echo e(url('/pembagianOfficeboy')); ?>">Office Boy</a></li>
                            </ul>
                        </li>

                        <?php

                        use Illuminate\Support\Facades\Auth;

                        $roleadmin = Auth::user()->role;
                        if ($roleadmin == "admin") {
                        ?> <li>
                                <a href="<?php echo e(url('/pegawai')); ?>" class="wave-effect"><i class="ti-user"></i><span> Pegawai </span></a>
                            </li>

                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="ti-user"></i> <span> Admin </span> <span class="pull-right"><i class="mdi mdi-plus"></i></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="<?php echo e(url('/IT')); ?>">Teknologi Informasi</a></li>
                                    <li><a href="<?php echo e(url('/pemasaran')); ?>">Pemasaran</a></li>
                                    <li><a href="<?php echo e(url('/SDM')); ?>">SDM</a></li>
                                    <li><a href="<?php echo e(url('/keuangan')); ?>">Keuangan</a></li>
                                    <li><a href="<?php echo e(url('/distribusi')); ?>">Distribusi</a></li>
                                    <li><a href="<?php echo e(url('/pengembanganperusahaan')); ?>">Pengembangan Perusahaan</a></li>
                                    <li><a href="<?php echo e(url('/pengendalian')); ?>">Pengendalian Teknik</a></li>
                                    <li><a href="<?php echo e(url('/pengadaan')); ?>">Pengadaan dan Logistik</a></li>
                                    <li><a href="<?php echo e(url('/perencanaan')); ?>">Perencanaan Teknik</a></li>
                                    <li><a href="<?php echo e(url('/produksi')); ?>">Produksi</a></li>
                                    <li><a href="<?php echo e(url('/SPI')); ?>">Satuan Pengawasan Intern</a></li>
                                    <li><a href="<?php echo e(url('/sekper')); ?>">Sekertaris Perusahaan</a></li>
                                    <li><a href="<?php echo e(url('/satpam')); ?>">Satpam</a></li>
                                    <li><a href="<?php echo e(url('/officeboy')); ?>">Office Boy</a></li>
                                </ul>
                            </li>
                            <li>
                                
                                <a href="<?php echo e(url('/refresh')); ?>" class="waves-effect" onclick="return confirm('Data Dashboard kembali ke awal dan pembagian juz terbagi otomatis. Ingin melanjutkan ? ')"><i class="ti-trash"></i><span> RESET ULANG </span></a>
                            </li>
                            <!-- <li>
                                <a href="<?php echo e(route('register')); ?>" class="waves-effect"><i class="ti-user"></i><span> Register </span></a>
                            </li> -->
                        <?php
                        }
                        if ($roleadmin == "adminIT") { ?>
                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="ti-user"></i> <span> Admin </span> <span class="pull-right"><i class="mdi mdi-plus"></i></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="<?php echo e(url('/IT')); ?>">Teknologi Informasi</a></li>
                                </ul>
                            </li>
                        <?php
                        }
                        if ($roleadmin == "adminPemasaran") { ?>
                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="ti-user"></i> <span> Admin </span> <span class="pull-right"><i class="mdi mdi-plus"></i></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="<?php echo e(url('/pemasaran')); ?>">Pemasaran</a></li>
                                </ul>
                            </li>
                        <?php
                        }
                        if ($roleadmin == "adminSDM") { ?>
                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="ti-user"></i> <span> Admin </span> <span class="pull-right"><i class="mdi mdi-plus"></i></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="<?php echo e(url('/SDM')); ?>">SDM</a></li>
                                </ul>
                            </li>
                        <?php
                        }
                        if ($roleadmin == "adminKeuangan") { ?>
                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="ti-user"></i> <span> Admin </span> <span class="pull-right"><i class="mdi mdi-plus"></i></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="<?php echo e(url('/keuangan')); ?>">Keuangan</a></li>
                                </ul>
                            </li>
                        <?php
                        }
                        if ($roleadmin == "adminDistribusi") { ?>
                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="ti-user"></i> <span> Admin </span> <span class="pull-right"><i class="mdi mdi-plus"></i></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="<?php echo e(url('/distribusi')); ?>">Distribusi</a></li>
                                </ul>
                            </li>
                        <?php
                        }
                        if ($roleadmin == "adminPengembanganperusahaan") { ?>
                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="ti-user"></i> <span> Admin </span> <span class="pull-right"><i class="mdi mdi-plus"></i></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="<?php echo e(url('/pengembanganperusahaan')); ?>">Pengembangan Perusahaan</a></li>
                                </ul>
                            </li>
                        <?php
                        }
                        if ($roleadmin == "adminPengendalian") { ?>
                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="ti-user"></i> <span> Admin </span> <span class="pull-right"><i class="mdi mdi-plus"></i></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="<?php echo e(url('/pengendalian')); ?>">Pengendalian Teknik</a></li>
                                </ul>
                            </li>
                        <?php
                        }
                        if ($roleadmin == "adminPengadaan") { ?>
                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="ti-user"></i> <span> Admin </span> <span class="pull-right"><i class="mdi mdi-plus"></i></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="<?php echo e(url('/pengadaan')); ?>">Pengadaan dan Logistik</a></li>
                                </ul>
                            </li>
                        <?php
                        }
                        if ($roleadmin == "adminPerencanaan") { ?>
                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="ti-user"></i> <span> Admin </span> <span class="pull-right"><i class="mdi mdi-plus"></i></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="<?php echo e(url('/perencanaan')); ?>">Perencanaan Teknik</a></li>
                                </ul>
                            </li>
                        <?php
                        }
                        if ($roleadmin == "adminProduksi") { ?>
                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="ti-user"></i> <span> Admin </span> <span class="pull-right"><i class="mdi mdi-plus"></i></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="<?php echo e(url('/produksi')); ?>">Produksi</a></li>
                                </ul>
                            </li>
                        <?php
                        }
                        if ($roleadmin == "adminSPI") { ?>
                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="ti-user"></i> <span> Admin </span> <span class="pull-right"><i class="mdi mdi-plus"></i></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="<?php echo e(url('/SPI')); ?>">Satuan Pengawasan Intern</a></li>
                                </ul>
                            </li>
                        <?php
                        }
                        if ($roleadmin == "adminSekper") { ?>
                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="ti-user"></i> <span> Admin </span> <span class="pull-right"><i class="mdi mdi-plus"></i></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="<?php echo e(url('/sekper')); ?>">Sekertaris Perusahaan</a></li>
                                </ul>
                            </li>
                        <?php
                        }
                        if ($roleadmin == "adminSatpam") { ?>
                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="ti-user"></i> <span> Admin </span> <span class="pull-right"><i class="mdi mdi-plus"></i></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="<?php echo e(url('/satpam')); ?>">SATPAM</a></li>
                                </ul>
                            </li>
                        <?php
                        }
                        if ($roleadmin == "adminOfficeboy") { ?>
                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="ti-user"></i> <span> Admin </span> <span class="pull-right"><i class="mdi mdi-plus"></i></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="<?php echo e(url('/officeboy')); ?>">Officeboy</a></li>
                                </ul>
                            </li>
                        <?php
                        } else {
                        }
                        ?>



                        <!-- <li>
                            <a href="typography.html" class="waves-effect"><i class="ti-ruler-pencil"></i><span> Typography <span class="badge badge-primary pull-right">6</span></span></a>
                        </li>

                        <li class="has_sub">
                            <a href="javascript:void(0);" class="waves-effect"><i class="ti-agenda"></i> <span> UI Elements </span> <span class="pull-right"><i class="mdi mdi-plus"></i></span></a>
                            <ul class="list-unstyled">
                                <li><a href="ui-buttons.html">Buttons</a></li>
                                <li><a href="ui-panels.html">Panels</a></li>
                                <li><a href="ui-tabs-accordions.html">Tabs &amp; Accordions</a></li>
                                <li><a href="ui-modals.html">Modals</a></li>
                                <li><a href="ui-components.html">Components</a></li>
                                <li><a href="ui-progressbars.html">Progress Bars</a></li>
                                <li><a href="ui-alerts.html">Alerts</a></li>
                                <li><a href="ui-sweet-alert.html">Sweet-Alert</a></li>
                                <li><a href="ui-grid.html">Grid</a></li>
                            </ul>
                        </li>

                        <li class="has_sub">
                            <a href="javascript:void(0);" class="waves-effect"><i class="ti-wand"></i> <span> Icons </span> <span class="pull-right"><i class="mdi mdi-plus"></i></span></a>
                            <ul class="list-unstyled">
                                <li><a href="icons-material.html">Material Design</a></li>
                                <li><a href="icons-ion.html">Ion Icons</a></li>
                                <li><a href="icons-fontawesome.html">Font awesome</a></li>
                                <li><a href="icons-themify.html">Themify Icons</a></li>
                            </ul>
                        </li>

                        <li class="has_sub">
                            <a href="javascript:void(0);" class="waves-effect"><i class="ti-write"></i><span> Forms </span><span class="pull-right"><i class="mdi mdi-plus"></i></span></a>
                            <ul class="list-unstyled">
                                <li><a href="form-elements.html">General Elements</a></li>
                                <li><a href="form-validation.html">Form Validation</a></li>
                                <li><a href="form-advanced.html">Advanced Form</a></li>
                                <li><a href="form-wysiwyg.html">WYSIWYG Editor</a></li>
                                <li><a href="form-uploads.html">Multiple File Upload</a></li>
                            </ul>
                        </li>

                        <li class="has_sub">
                            <a href="javascript:void(0);" class="waves-effect"><i class="ti-menu-alt"></i><span> Tables </span><span class="pull-right"><i class="mdi mdi-plus"></i></span></a>
                            <ul class="list-unstyled">
                                <li><a href="tables-basic.html">Basic Tables</a></li>
                                <li><a href="tables-datatable.html">Data Table</a></li>
                            </ul>
                        </li>

                        <li class="has_sub">
                            <a href="javascript:void(0);" class="waves-effect"><i class="ti-pie-chart"></i><span> Charts </span><span class="pull-right"><i class="mdi mdi-plus"></i></span></a>
                            <ul class="list-unstyled">
                                <li><a href="charts-morris.html">Morris Chart</a></li>
                                <li><a href="charts-chartjs.html">Chartjs</a></li>
                                <li><a href="charts-flot.html">Flot Chart</a></li>
                                <li><a href="charts-other.html">Other Chart</a></li>
                            </ul>
                        </li>

                        <li class="has_sub">
                            <a href="javascript:void(0);" class="waves-effect"><i class="ti-map-alt"></i><span> Maps </span><span class="pull-right"><i class="mdi mdi-plus"></i></span></a>
                            <ul class="list-unstyled">
                                <li><a href="maps-google.html"> Google Map</a></li>
                                <li><a href="maps-vector.html"> Vector Map</a></li>
                            </ul>
                        </li>

                        <li>
                            <a href="calendar.html" class="waves-effect"><i class="ti-calendar"></i><span> Calendar <span class="badge badge-primary pull-right">NEW</span></span></a>
                        </li>

                        <li class="has_sub">
                            <a href="javascript:void(0);" class="waves-effect"><i class="ti-files"></i><span> Pages </span><span class="pull-right"><i class="mdi mdi-plus"></i></span></a>
                            <ul class="list-unstyled">
                                <li><a href="pages-timeline.html">Timeline</a></li>
                                <li><a href="pages-invoice.html">Invoice</a></li>
                                <li><a href="pages-directory.html">Directory</a></li>
                                <li><a href="pages-login.html">Login</a></li>
                                <li><a href="pages-register.html">Register</a></li>
                                <li><a href="pages-recoverpw.html">Recover Password</a></li>
                                <li><a href="pages-lock-screen.html">Lock Screen</a></li>
                                <li><a href="pages-blank.html">Blank Page</a></li>
                                <li><a href="pages-404.html">Error 404</a></li>
                                <li><a href="pages-500.html">Error 500</a></li>
                            </ul>
                        </li> -->

                        <!--<li class="has_sub">-->
                        <!--<a href="javascript:void(0);" class="waves-effect"><i class="ti-share"></i><span>Multi Menu </span><span class="pull-right"><i class="mdi mdi-plus"></i></span></a>-->
                        <!--<ul>-->
                        <!--<li class="has_sub">-->
                        <!--<a href="javascript:void(0);" class="waves-effect"><span>Menu Item 1.1</span> <span class="pull-right"><i class="mdi mdi-plus"></i></span></a>-->
                        <!--<ul style="">-->
                        <!--<li><a href="javascript:void(0);"><span>Menu Item 2.1</span></a></li>-->
                        <!--<li><a href="javascript:void(0);"><span>Menu Item 2.2</span></a></li>-->
                        <!--</ul>-->
                        <!--</li>-->
                        <!--<li>-->
                        <!--<a href="javascript:void(0);"><span>Menu Item 1.2</span></a>-->
                        <!--</li>-->
                        <!--</ul>-->
                        <!--</li>-->
                    </ul>
                </div>
                <div class="clearfix"></div>
            </div> <!-- end sidebarinner -->
        </div>
        <!-- Left Sidebar End -->

        <!-- Start right Content here -->

        <div class="content-page">
            <!-- Start content -->
            <div class="content">
                <div class="container">

                    <!-- Page-Title -->
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="page-header-title">
                                <h4 class="pull-left page-title">STATUS</h4>

                                <ol class="breadcrumb pull-right">
                                    <?php
                                    $iduser = Auth::user()->id;
                                    ?>

                                    <li>
                                        <a href="<?php echo e(url('/user/terlaksana/'.$iduser)); ?>" class="btn btn-sm btn-primary">Terlaksana</a>
                                    </li>
                                    <li><a href="<?php echo e(url('/user/berhalangan/'.$iduser)); ?>" class="btn btn-sm btn-warning">Berhalangan</a></li>
                                    <!-- <li>
                                        <button class="btn btn-default waves-effect waves-light" id="sa-success">Click me</button>
                                    </li> -->

                                </ol>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <?php echo $__env->yieldContent('konten'); ?>
                    </div>




                    <!-- End Row -->


                </div> <!-- container -->

            </div> <!-- content -->

            <footer class="footer">
                2022 © FRS
            </footer>

        </div>
        <!-- End Right content here -->

    </div>
    <!-- END wrapper -->


    <!-- jQuery  -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/modernizr.min.js"></script>
    <script src="assets/js/detect.js"></script>
    <script src="assets/js/fastclick.js"></script>
    <script src="assets/js/jquery.slimscroll.js"></script>
    <script src="assets/js/jquery.blockUI.js"></script>
    <script src="assets/js/waves.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/jquery.nicescroll.js"></script>
    <script src="assets/js/jquery.scrollTo.min.js"></script>

    <script src="assets/plugins/jquery-sparkline/jquery.sparkline.min.js"></script>

    <!-- Datatables-->
    <script src="assets/plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="assets/plugins/datatables/dataTables.bootstrap.js"></script>
    <script src="assets/plugins/datatables/dataTables.responsive.min.js"></script>
    <script src="assets/plugins/datatables/responsive.bootstrap.min.js"></script>
    <script src="assets/pages/dashborad.js"></script>
    <script src="assets/js/app.js"></script>



</body>

</html><?php /**PATH C:\xampp\htdocs\tilawah_quran\resources\views/master.blade.php ENDPATH**/ ?>