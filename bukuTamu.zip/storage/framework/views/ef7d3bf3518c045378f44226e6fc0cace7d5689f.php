

<?php $__env->startSection('konten'); ?>
<?php

use Carbon\Carbon;
?>

<h4>Selamat Datang <b><?php echo e(Auth::user()->name); ?></b>, Anda Login sebagai <b><?php echo e(Auth::user()->role); ?></b>.</h4>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">

                </div>
                <div class="card-body">

                    <?php if(Session::has('sukses')): ?>
                    <div class="alert alert-success">
                        <?php echo e(Session::get('sukses')); ?>

                    </div>
                    <?php endif; ?>




                </div>
            </div>
        </div>

    </div>
</div>

<div class="row">
    <div class="col-sm-6 col-lg-4">
        <div class="panel panel-primary text-center">
            <div class="panel-heading">
                <h4 class="panel-title">Kendaraan Tersedia</h4>
            </div>
            <div class="panel-body">
                <h3 class=""><b><?php echo e($kendaraan_tersedia); ?></b></h3>
                <p class="text-muted"><b><?php $coba = ($kendaraan_tersedia / $total_kendaraan) * 100;
                                            echo $coba ?> %</b> dari Total Seluruh Kendaraan</p>
            </div>
        </div>
    </div>

    <div class="col-sm-6 col-lg-4">
        <div class="panel panel-primary text-center">
            <div class="panel-heading">
                <h4 class="panel-title">Peminjaman Diajukan</h4>
            </div>
            <div class="panel-body">
                <h3 class=""><b><?php echo e($notifDiajukan); ?></b></h3>
                <p class="text-muted"><b>Pengajuan</b> </p>
            </div>
        </div>
    </div>

    <div class="col-sm-6 col-lg-4">
        <div class="panel panel-primary text-center">
            <div class="panel-heading">
                <h4 class="panel-title">Peminjaman Berlangsung</h4>
            </div>
            <div class="panel-body">
                <h3 class=""><b><?php echo e($peminjamanBerlangsung); ?></b></h3>
                <p class="text-muted"><b>Proses</b> </p>
            </div>
        </div>
    </div>

    <!--<div class="col-sm-6 col-lg-3">
        <div class="panel panel-primary text-center">
            <div class="panel-heading">
                <h4 class="panel-title">Peminjaman Selesai</h4>
            </div>
            <div class="panel-body">
                <h3 class=""><b><?php echo e($peminjamanSelesai); ?></b></h3>
                <p class="text-muted"><b>Peminjaman</b> </p>
            </div>
        </div>
    </div>-->
</div>

<div class="row">
    <!-- BAR Chart -->
    <div class="col-lg-6">
        <div class="panel panel-border panel-primary">
            <div class="panel-heading">
                <h3 class="panel-title">Record Peminjaman</h3>
            </div>
            <div class="panel-body">
                <canvas id="myChart"></canvas>
            </div>
        </div>
    </div> <!-- col -->

    <!--  Line Chart -->
    <div class="col-lg-6">
        <div class="panel panel-border panel-primary">
            <div class="panel-heading">
                <h3 class="panel-title">Line Chart</h3>
            </div>
            <div class="panel-body">
                <div id="morris-line-example" style="height: 300px"></div>
            </div>
        </div>
    </div> <!-- col -->
</div> <!-- End row-->




<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chartjs-adapter-date-fns/dist/chartjs-adapter-date-fns.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/chartjs-plugin-datalabels/2.0.0/chartjs-plugin-datalabels.min.js" integrity="sha512-R/QOHLpV1Ggq22vfDAWYOaMd5RopHrJNMxi8/lJu8Oihwi4Ho4BRFeiMiCefn9rasajKjnx9/fTQ/xkWnkDACg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<script>
    const ctx = document.getElementById('myChart').getContext('2d');
    const myChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Ags', 'Sept', 'Okt', 'Nov', 'Des'],
            datasets: [{
                label: '# of Votes',
                data: [<?php echo $record_peminjaman_jan ?>, <?php echo $record_peminjaman_feb ?>, <?php echo $record_peminjaman_mar ?>, <?php echo $record_peminjaman_apr ?>, <?php echo $record_peminjaman_mei ?>, <?php echo $record_peminjaman_jun ?>, <?php echo $record_peminjaman_jul ?>, <?php echo $record_peminjaman_ags ?>, <?php echo $record_peminjaman_sep ?>, <?php echo $record_peminjaman_okt ?>, <?php echo $record_peminjaman_nov ?>, <?php echo $record_peminjaman_des ?>],
                backgroundColor: [
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(54, 162, 235, 0.2)',
                    'rgba(255, 206, 86, 0.2)',
                    'rgba(75, 192, 192, 0.2)',
                    'rgba(153, 102, 255, 0.2)',
                    'rgba(255, 159, 64, 0.2)'
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)',
                    'rgba(255, 159, 64, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
</script>

<!--  -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bukuTamu\resources\views/home.blade.php ENDPATH**/ ?>