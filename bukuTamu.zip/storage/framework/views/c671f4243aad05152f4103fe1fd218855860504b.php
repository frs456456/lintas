

<?php $__env->startSection('konten'); ?>
</br>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">

            <div class="card">
                <div class="card-header">
                    Data Pegawai
                    <a href="<?php echo e(url('/pegawai_tambah')); ?>" class="float-right btn btn-sm btn-primary">Tambah</a>
                </div>
                </br>

                <div class="card-body">

                    <?php if(Session::has('sukses')): ?>
                    <div class="alert alert-success">
                        <?php echo e(Session::get('sukses')); ?>

                    </div>
                    <?php endif; ?>

                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th width="1%">No</th>

                                <th>Nama Pegawai</th>
                                <th>Jabatan</th>
                                <th>Divisi</th>
                                <th>Agama</th>
                                <th width="15%" class="text-center">OPSI</th>
                            </tr>
                        </thead>

                        <tbody>

                            <?php
                            $no = 1;
                            ?>
                            <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($no++); ?></td>
                                <td><?php echo e($p->nama_pegawai); ?></td>
                                <td><?php echo e($p->jabatan); ?></td>
                                <td><?php echo e($p->divisi); ?></td>
                                <td><?php echo e($p->agama); ?></td>
                                <td class="text-center">
                                    <a href="<?php echo e(url('/pegawai_edit'.$p->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                                    <a href="<?php echo e(url('/pegawai/hapus/'.$p->id)); ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin Hapus ??')">Hapus</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                    <?php echo e($pegawai->links()); ?>

                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tilawah_quran\resources\views/pegawai.blade.php ENDPATH**/ ?>