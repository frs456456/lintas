

<?php $__env->startSection('konten'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<div class="container">


    <div class="row justify-content-center">
        <div class="col-md-12">

            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="alert alert-success d-none" id="msg_div">
                                <span id="res_message"></span>
                            </div>
                            Tambah Data

                            <a href="<?php echo e(url('/')); ?>" class="float-right btn btn-sm btn-primary">Kembali</a>
                        </div>

                        </br>
                        <div class="card-body">
                            <form name="frm_add" id="frm_add" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="panel panel-border panel-primary">

                                            <div class="panel-body">
                                                <div class="form-group"><label class="control-label">Nama
                                                        Pegawai</label>
                                                    <div><select name="pegawai" id="pegawai" class="form-control">
                                                            <option value="">- Pilih Pegawai</option>
                                                            <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pegawai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($pegawai->id); ?>"><?php echo e($pegawai->nama); ?>

                                                            </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="form-group"><label class="control-label">Handphone</label>
                                                    <div><select name="handphone" id="handphone" class="form-control">
                                                            <option value="">- Pilih Handphone</option>
                                                            <?php $__currentLoopData = $handphone; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $handphone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($handphone->id); ?>"><?php echo e($handphone->merk); ?>

                                                                || Imei 1 :
                                                                <?php echo e($handphone->imei1); ?>

                                                            </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="form-group"><label class="control-label" for="">Kondisi
                                                        Fisik</label>
                                                    <div><select name="fisik" id="fisik" class="form-control">
                                                            <option value="">- Pilih Kondisi</option>
                                                            <option value="sangat baik">Sangat Baik</option>
                                                            <option value="baik">Baik</option>
                                                            <option value="rusak sedang">Rusak Sedang</option>
                                                            <option value="rusak parah">Rusak Parah</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="form-group"><label class="control-label" for="">Kondisi
                                                        Fungsi</label>
                                                    <div><select name="fungsi" id="fungsi" class="form-control">
                                                            <option value="">- Pilih Kondisi</option>
                                                            <option value="sangat baik">Sangat Baik</option>
                                                            <option value="baik">Baik</option>
                                                            <option value="rusak sedang">Rusak Sedang</option>
                                                            <option value="rusak parah">Rusak Parah</option>
                                                        </select>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="panel panel-border panel-primary">

                                            <div class="panel-body">
                                                <div class="form-group"><label class="control-label" for="">Keadaan
                                                        IMEI</label>
                                                    <div><select name="m_imei" id="m_imei" class="form-control">
                                                            <option value="">- Pilih</option>
                                                            <option value="sesuai">Sesuai</option>
                                                            <option value="tidak sesuai">Tidak Sesuai</option>
                                                        </select>
                                                    </div>
                                                </div>


                                                <div class="form-group"><label class="control-label">Keterangan</label>
                                                    <div><textarea class="form-control" name="keterangan" id="keterangan" cols="30" rows="4"></textarea>
                                                    </div>
                                                </div>

                                                <div class="form-group"><label class="control-label">Pegawai
                                                        Sebelumnya</label>
                                                    <div><input type="text" name="id_pegawai_sebelumnya" id="id_pegawai_sebelumnya" class="form-control"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div> <!-- end row -->



                                <div class="form-group"><label class="control-label"></label>
                                    <button id="simpan" type="submit" class="btn btn-primary waves-effect waves-light">Simpan</button>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
<link rel="stylesheet" href="">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.8/css/select2.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.8/js/select2.min.js"></script>
<script>
    $("#pegawai").select2({
        width: '100%'
    });
    $("#handphone").select2({
        width: '100%'
    });
    $("#fisik").select2({
        width: '100%'
    });
    $("#fungsi").select2({
        width: '100%'
    });
    $("#m_imei").select2({
        width: '100%'
    });

    $('#frm_add').on('submit', function(event) {
        event.preventDefault();
        //MENGAMBIL ID INPUT
        pegawai = $('#pegawai').val();
        handphone = $('#handphone').val();
        fisik = $('#fisik').val();
        fungsi = $('#fungsi').val();
        m_imei = $('#m_imei').val();
        keterangan = $('#keterangan').val();
        id_pegawai_sebelumnya = $('#id_pegawai_sebelumnya').val();


        $.ajax({
            url: "<?php echo e(route('tambah_coba')); ?>",
            type: "POST",
            data: {
                "_token": "<?php echo e(csrf_token()); ?>",
                pegawai: pegawai,
                handphone: handphone,
                fisik: fisik,
                fungsi: fungsi,
                m_imei: m_imei,
                keterangan: keterangan,
                id_pegawai_sebelumnya: id_pegawai_sebelumnya,
            },
            //TAMPIL SUKSES MESSAGE
            success: function(response) {
                $('#res_message').show();
                $('#res_message').html(response.msg);
                $('#msg_div').removeClass('d-none');

                document.getElementById("frm_add").reset();

                setTimeout(function() {
                    $('#res_message').hide();
                    $('#msg_div').hide();
                }, 4000);

            },

        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventaris\resources\views/maintenance_tambah.blade.php ENDPATH**/ ?>