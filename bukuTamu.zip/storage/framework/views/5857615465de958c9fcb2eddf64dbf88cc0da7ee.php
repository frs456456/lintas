

<?php $__env->startSection('konten'); ?>
</br>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">

            <div class="card">
                <div class="card-header">
                    Form Input Pembagian
                    <a href="<?php echo e(url('/admin/tambah')); ?>" class="float-right btn btn-sm btn-primary">Tambah</a>
                </div>
                </br>

                <div class="card-body">

                    <?php if(Session::has('sukses')): ?>
                    <div class="alert alert-success">
                        <?php echo e(Session::get('sukses')); ?>

                    </div>
                    <?php endif; ?>

                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th width="1%">No</th>
                                <th>Divisi</th>
                                <th>Jumlah Pegawai</th>
                                <th>Juz ke</th>
                                <th width="15%" class="text-center">OPSI</th>
                            </tr>
                        </thead>

                        <tbody>

                            <?php
                            $no = 1;
                            ?>
                            <?php $__currentLoopData = $admin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($no++); ?></td>
                                <td><?php echo e($a->divisi); ?></td>
                                <td><?php echo e($a->jumlahpegawai); ?></td>
                                <td><?php echo e($a->jus_ke); ?></td>
                                <td class="text-center">
                                    <a href="<?php echo e(url('/admin/edit/'.$a->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                                    <a href="<?php echo e(url('/admin/hapus/'.$a->id)); ?>" class="btn btn-sm btn-danger">Hapus</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tilawah_quran\resources\views/admin.blade.php ENDPATH**/ ?>