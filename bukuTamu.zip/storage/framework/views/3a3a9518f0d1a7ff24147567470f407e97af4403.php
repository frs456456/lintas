<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login - Aplikasi Khatam Quran</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-info text-white">
    <div class="container"><br>
        <div class="col-md-4 col-md-offset-4">
            <center>
                <img src="<?php echo e(('img/logopt.png')); ?>" width="130">
            </center>
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h2 class="text-center"><b>TIRTA ASASTA</b><br>Khatam Quran</h3>
                </div>

                <div class="card-body">

                    <?php if(session('error')): ?>
                    <div class="alert alert-danger">
                        <b>Opps!</b> <?php echo e(session('error')); ?>

                    </div>
                    <?php endif; ?>
                    <form action="<?php echo e(route('actionlogin')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label>User</label>
                            <input type="text" name="email" class="form-control" placeholder="Gunakan NIP" required="">
                        </div>
                        <div class="form-group">
                            <label>Password</label>
                            <input type="password" name="password" class="form-control" placeholder="12345" required="">
                        </div>
                        <button type="submit" class="btn btn-primary btn-block">Log In</button>
                        <hr>
                        <!-- <p class="text-center">Belum punya akun? <a href="#">Register</a> sekarang!</p> -->
                    </form>
                </div>
                <?php
                ?>

            </div>
        </div>
    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\tilawah_quran\resources\views/login.blade.php ENDPATH**/ ?>