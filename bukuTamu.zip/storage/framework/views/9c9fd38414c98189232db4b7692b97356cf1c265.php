

<?php $__env->startSection('konten'); ?>
<?php echo e($pembagianOfficeboy->links(('pagination::bootstrap-4'))); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                </div>
                <div class="card-body">

                    <?php if(Session::has('sukses')): ?>
                    <div class="alert alert-success">
                        <?php echo e(Session::get('sukses')); ?>

                    </div>
                    <?php endif; ?>

                    
                    <div class="row">
                        <div class="col-md-12">
                            <div class="panel panel-success">
                                <div class="panel-heading">
                                    <h3 class="panel-title text-white">Pembagian Tilawah</h3>
                                </div>
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-xs-12">
                                            <div class="table-responsive">
                                                <table class="table table-striped">
                                                    <thead>
                                                        <tr>
                                                            <th width="1%">No</th>
                                                            <th>Nama Surat</th>
                                                            <th>Ayat Ke</th>
                                                            <th>Bacaan</th>
                                                            <th>Juz ke</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                        $no = 1;
                                                        ?>
                                                        <?php $__currentLoopData = $pembagianOfficeboy; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pembagianOfficeboy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($no++); ?></td>
                                                            <td><?php echo e($pembagianOfficeboy->nama_surat); ?></td>
                                                            <td>Ayat <?php echo e($pembagianOfficeboy->ayat_ke); ?></td>
                                                            <td <strong style="font-size: 25px;"><?php echo e($pembagianOfficeboy->bacaan); ?></strong></td>
                                                            <td>Juz <?php echo e($pembagianOfficeboy->jus_ke); ?></td>
                                                        </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> <!-- End row -->
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tilawah_quran\resources\views/pembagianOfficeboy.blade.php ENDPATH**/ ?>