

<?php $__env->startSection('konten'); ?>
</br>
<div class="container">
    <div class="row justify-content-center">

        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    Form Input Pembagian
                    <!-- <a href="<?php echo e(url('/sekper/tambah')); ?>" class="float-right btn btn-sm btn-primary">Tambah</a> -->
                </div>
                </br>

                <div class="card-body">

                    <?php if(Session::has('sukses')): ?>
                    <div class="alert alert-success">
                        <?php echo e(Session::get('sukses')); ?>

                    </div>
                    <?php endif; ?>

                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th width="1%">No</th>
                                <th>ID</th>
                                <th>Juz</th>
                                <!-- <th>Status</th> -->
                                <th width="15%" class="text-center">OPSI</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php
                            $no = 1;
                            ?>
                            <?php $__currentLoopData = $sekper; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sekper): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($no++); ?></td>
                                <td><?php echo e($sekper->id); ?></td>
                                <td><?php echo e($sekper->jus_ke); ?></td>
                                <!-- <td><?php echo e($sekper->status); ?></td> -->

                                <td class="text-center">
                                    <a href="<?php echo e(url('/sekper_edit'.$sekper->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                                    <!-- <a href="<?php echo e(url('/sekper/hapus/'.$sekper->id)); ?>" class="btn btn-sm btn-danger">Hapus</a> -->
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tilawah_quran\resources\views/sekper.blade.php ENDPATH**/ ?>