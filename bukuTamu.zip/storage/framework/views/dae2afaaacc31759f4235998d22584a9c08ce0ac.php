

<?php $__env->startSection('konten'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">

            <div class="card">
                <div class="card-header">
                    Edit Data
                    <a href="<?php echo e(url('/pegawai')); ?>" class="float-right btn btn-sm btn-primary">Kembali</a>
                </div>
                <div class="card-body">

                    <form method="post" action="<?php echo e(url('/pegawai/update/'.$pegawai->id)); ?>">

                        <?php echo csrf_field(); ?>

                        <?php echo e(method_field('PUT')); ?>


                        <div class="form-group">

                            <label>Nama Pegawai</label>
                            <input type="text" name="nama_pegawai" class="form-control" value="<?php echo e($pegawai->nama_pegawai); ?>">

                            <?php if($errors->has('nama_pegawai')): ?>
                            <span class="text-danger">
                                <strong><?php echo e($errors->first('nama_pegawai')); ?></strong>
                            </span>
                            <?php endif; ?>

                        </div>

                        <div class="form-group">

                            <label>Jabatan</label>
                            <select class="form-control" name="jabatan" id="">
                                <option <?php if ($pegawai->jabatan == "staff") {
                                            echo "selcted='selected'";
                                        } ?> value="staff">Staff</option>

                                <option <?php if ($pegawai->jabatan == "supervisor") {
                                            echo "selcted='selected'";
                                        } ?> value="supervisor">Supervisor</option>


                                <option <?php if ($pegawai->jabatan == "manajer") {
                                            echo "selected='selected'";
                                        } ?> value="manajer">Manajer</option>

                            </select>


                            <?php if($errors->has('jabatan')): ?>
                            <span class="text-danger">
                                <strong><?php echo e($errors->first('jabatan')); ?></strong>
                            </span>
                            <?php endif; ?>

                        </div>

                        <div class="form-group">

                            <label>Jabatan</label>
                            <select class="form-control" name="divisi" id="">
                                <option <?php if ($pegawai->divisi == "IT") {
                                            echo "selcted='selected'";
                                        } ?> value="IT">Teknologi Informasi</option>


                                <option <?php if ($pegawai->divisi == "SDM") {
                                            echo "selected='selected'";
                                        } ?> value="SDM">SDM</option>

                                <option <?php if ($pegawai->divisi == "pemasaran") {
                                            echo "selected='selected'";
                                        } ?> value="pemasaran">Pemasaran</option>

                                <option <?php if ($pegawai->divisi == "keuangan") {
                                            echo "selected='selected'";
                                        } ?> value="keuangan">Keuangan</option>
                            </select>


                            <?php if($errors->has('divisi')): ?>
                            <span class="text-danger">
                                <strong><?php echo e($errors->first('divisi')); ?></strong>
                            </span>
                            <?php endif; ?>

                        </div>

                        <div class="form-group">

                            <label>Agama</label>
                            <select class="form-control" name="agama" id="">
                                <option <?php if ($pegawai->agama == "islam") {
                                            echo "selcted='selected'";
                                        } ?> value="islam">Islam</option>


                                <option <?php if ($pegawai->agama == "Non Muslim") {
                                            echo "selected='selected'";
                                        } ?> value="Non Muslim">Non Muslim</option>
                            </select>


                            <?php if($errors->has('agama')): ?>
                            <span class="text-danger">
                                <strong><?php echo e($errors->first('agama')); ?></strong>
                            </span>
                            <?php endif; ?>

                        </div>

                        <input type="submit" class="btn btn-primary" value="Simpan">

                    </form>

                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tilawah_quran\resources\views/pegawai_edit.blade.php ENDPATH**/ ?>