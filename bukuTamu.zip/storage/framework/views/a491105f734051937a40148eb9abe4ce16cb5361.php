<!-- <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login - Aplikasi Khatam Quran</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-info text-white">
    <div class="container"><br>
        <div class="col-md-4 col-md-offset-4">
            <center>
                <img src="<?php echo e(('img/logopt.png')); ?>" width="130">
            </center>
            <div class="card">
                <div class="card-header bg-success text-white">
                    <h2 class="text-center"><b>INVENTARIS</b><br></h3>
                </div>

                <div class="card-body">

                    <?php if(session('error')): ?>
                    <div class="alert alert-danger">
                        <b>Opps!</b> <?php echo e(session('error')); ?>

                    </div>
                    <?php endif; ?>
                    <form action="<?php echo e(route('actionlogin')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label>User</label>
                            <input type="text" name="email" class="form-control" placeholder="Gunakan NIP" required="">
                        </div>
                        <div class="form-group">
                            <label>Password</label>
                            <input type="password" name="password" class="form-control" placeholder="12345" required="">
                        </div>
                        <button type="submit" class="btn btn-primary btn-block">Log In</button>
                        <hr>
                       
                    </form>
                </div>
              

            </div>
        </div>
    </div>
</body>

</html> -->

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title>Inventaris</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta content="Admin Dashboard" name="description" />
    <meta content="ThemeDesign" name="author" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />

    <link rel="shortcut icon" href="assets/images/favicon.ico">

    <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="assets/css/icons.css" rel="stylesheet" type="text/css">
    <link href="assets/css/style.css" rel="stylesheet" type="text/css">

</head>


<body>

    <!-- Begin page -->
    <div class="accountbg"></div>
    <div class="wrapper-page">
        <div class="panel panel-color panel-primary panel-pages">

            <div class="panel-body">
                <h3 class="text-center m-t-0 m-b-30">
                    <span class="">Buku Tamu</span>
                </h3>
                <h4 class="text-muted text-center m-t-0"><b>Sign In</b></h4>

                <?php if(session('error')): ?>
                <div class="alert alert-danger">
                    <b>Opps!</b> <?php echo e(session('error')); ?>

                </div>
                <?php endif; ?>
                <form action="<?php echo e(route('actionlogin')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label>User</label>
                        <input type="text" name="email" class="form-control" placeholder="User name" required="">
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" name="password" class="form-control" placeholder="password" required="">
                    </div>
                    <button type="submit" class="btn btn-primary btn-block">Log In</button>
                    <hr>

                </form>
            </div>

        </div>
    </div>



    <!-- jQuery  -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/modernizr.min.js"></script>
    <script src="assets/js/detect.js"></script>
    <script src="assets/js/fastclick.js"></script>
    <script src="assets/js/jquery.slimscroll.js"></script>
    <script src="assets/js/jquery.blockUI.js"></script>
    <script src="assets/js/waves.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/jquery.nicescroll.js"></script>
    <script src="assets/js/jquery.scrollTo.min.js"></script>

    <script src="assets/js/app.js"></script>

</body>

</html><?php /**PATH C:\xampp\htdocs\bukuTamu\resources\views/login.blade.php ENDPATH**/ ?>