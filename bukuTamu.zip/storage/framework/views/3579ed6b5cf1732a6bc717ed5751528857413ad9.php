

<?php $__env->startSection('konten'); ?>
</br>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">

            <div class="card">
                <div class="card-header">
                    Edit Data
                    <a href="<?php echo e(url('/pengadaan')); ?>" class="float-right btn btn-sm btn-primary">Kembali</a>
                </div>
                <div class="card-body">

                    <form method="post" action="<?php echo e(url('/pengadaan/update/'.$pengadaan->id)); ?>">

                        <?php echo csrf_field(); ?>

                        <?php echo e(method_field('PUT')); ?>




                        <div class="form-group">

                            <label>Juz Ke</label>
                            <input type="number" name="jus_ke" class="form-control" value="<?php echo e($pengadaan->jus_ke); ?>">

                            <?php if($errors->has('jus_ke')): ?>
                            <span class="text-danger">
                                <strong><?php echo e($errors->first('jus_ke')); ?></strong>
                            </span>
                            <?php endif; ?>

                        </div>
                        <div class="form-group">

                            <label>Status</label>
                            <select class="form-control" name="status" id="">
                                <option <?php if ($pengadaan->status == "terlaksana") {
                                            echo "selcted='selected'";
                                        } ?> value="terlaksana">Sudah Terlaksana</option>


                                <option <?php if ($pengadaan->status == "belum") {
                                            echo "selected='selected'";
                                        } ?> value="belum">Belum Terlaksana</option>
                            </select>


                            <?php if($errors->has('status')): ?>
                            <span class="text-danger">
                                <strong><?php echo e($errors->first('status')); ?></strong>
                            </span>
                            <?php endif; ?>

                        </div>

                        <input type="submit" class="btn btn-primary" value="Simpan">

                    </form>

                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tilawah_quran\resources\views/pengadaan_edit.blade.php ENDPATH**/ ?>