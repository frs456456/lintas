<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Inventaris;
use App\Models\Handphone;
use App\Models\Pegawai;
use App\Models\Peminjaman;
use App\Models\Tamu;
use App\Models\Maintenance;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\InventarisExport;
use App\Exports\MaintenanceExport;
use App\Models\Kendaraan;
use Facade\FlareClient\Http\Response;

class HomeController extends Controller
{
    public function index()
    {
        return view('home');
    }

     //---------------------------------------------------------------------------------------//
    //---------------------------------------------------------------------------------------//

    public function inventaris()
    {
        $cobaimei = Inventaris::where('id','=','1')->value('imei');
        $cobaimeibaru = Inventaris::where('id', '=', '1')->value('imei_baru');

        $inventaris = Inventaris::all();
        return view('inventaris', ['inventaris' => $inventaris,'cobaimei'=>$cobaimei,'cobaimeibaru'=>$cobaimeibaru]);
    }

    public function export_excel()
    {
        return Excel::download(new InventarisExport(), 'inventaris.xlsx');
    }

    public function simpan_inventaris(Request $request)
    {
        $simpan = DB::table('inv_hp')->insert([
            'nama' => $request->post('nama'),
            'no_hp' => $request->post('no_hp'),
            'jabatan' => $request->post('jabatan'),
            'area' => $request->post('area'),
            'warna' => $request->post('warna'),
            'imei' => $request->post('imei'),
            'serial_number' => $request->post('serial_number'),
            'kd_inventaris' => $request->post('kd_inventaris'),
            'wilayah' => $request->post('wilayah'),
        ]);
        if ($simpan) {
            Session::flash('status', 'Data berhasil disimpan.');
        } else {
            Session::flash('status', 'Data gagal disimpan.');
        }
        return redirect('inventaris');
    }

    public function edit_inventaris(Request $request)
    {
        $data = Inventaris::findOrFail($request->get('id'));
        echo json_encode($data);
    }

    public function update_inventaris(Request $request)
   
    {
        $data = array(
            'nama' => $request->post('nama'),
            'no_hp' => $request->post('no_hp'),
            'jabatan' => $request->post('jabatan'),
            'area' => $request->post('area'),
            'warna' => $request->post('warna'),
            'imei' => $request->post('imei'),
            'serial_number' => $request->post('serial_number'),
            'kd_inventaris' => $request->post('kd_inventaris'),
            'wilayah' => $request->post('wilayah'),
            'imei_baru' => $request->post('imei_baru'),
            'keterangan' => $request->post('keterangan'),
            'tgl_maintenance'=>date('Y-m-d H:i:s'),
        );
        $simpan = DB::table('inv_hp')->where('id', '=', $request->post('id'))->update($data);
        if ($simpan) {
            Session::flash('status', 'Data berhasil diupdate.');
        } else {
            Session::flash('status', 'Data gagal diupdate.');
        }
        return redirect('inventaris')->with("sukses", "Inventaris berhasil diubah");
    }
   

    public function inventaris_hapus($id)
    {
        // hapus kategori berdasarkan id yang dipilih
        $inventaris = Inventaris::find($id);
        $inventaris->delete();

        return redirect('inventaris')->with("sukses", "inventaris berhasil dihapus");
    }
     //---------------------------------------------------------------------------------------//
    //---------------------------------------------------------------------------------------//


    //---------------------------------------------------------------------------------------//
    //---------------------------------------------------------------------------------------//

    public function handphone()
    {
        $handphone = Handphone::all();
        return view('handphone', ['handphone' => $handphone]);
    }

    public function simpan_handphone(Request $request)
    {
        $simpan = DB::table('handphone')->insert([
            'merk' => $request->post('merk'),
            'tipe' => $request->post('tipe'),
            'warna' => $request->post('warna'),
            'imei1' => $request->post('imei1'),
            'imei2' => $request->post('imei2'),
            'serial_number' => $request->post('serial_number'),
            'kode_inventaris' => $request->post('kode_inventaris'),
            'no_hp' => $request->post('no_hp'),
            'status' => 1,
        ]);
        if ($simpan) {
            Session::flash('status', 'Data berhasil disimpan.');
        } else {
            Session::flash('status', 'Data gagal disimpan.');
        }
        return redirect('handphone');
    }

    public function edit_handphone(Request $request)
    {
        $data = Handphone::findOrFail($request->get('id'));
        echo json_encode($data);
    }

    public function update_handphone(Request $request)

    {
        $data = array(
            'merk' => $request->post('merk'),
            'tipe' => $request->post('tipe'),
            'warna' => $request->post('warna'),
            'imei1' => $request->post('imei1'),
            'imei2' => $request->post('imei2'),
            'serial_number' => $request->post('serial_number'),
            'kode_inventaris' => $request->post('kode_inventaris'),
            'no_hp' => $request->post('no_hp'),
            'status' => 1,
        );
        $simpan = DB::table('handphone')->where('id', '=', $request->post('id'))->update($data);
        if ($simpan) {
            Session::flash('status', 'Data berhasil diupdate.');
        } else {
            Session::flash('status', 'Data gagal diupdate.');
        }
        return redirect('handphone')->with("sukses", "berhasil diubah");
    }

    public function handphone_hapus($id)
    {
        // hapus kategori berdasarkan id yang dipilih
        $handphone = Handphone::find($id);
        $handphone->delete();

        return redirect('handphone')->with("sukses", " berhasil dihapus");
    }
     //---------------------------------------------------------------------------------------//
    //---------------------------------------------------------------------------------------//


    //---------------------------------------------------------------------------------------//
    //---------------------------------------------------------------------------------------//

    public function pegawai()
    {
        $pegawai = Pegawai::all();
        $pegawaiedit = Pegawai::all();
        return view('pegawai', ['pegawai' => $pegawai, 'pegawaiedit'=> $pegawaiedit]);
    }

    public function simpan_pegawai(Request $request)
    {
        $simpan = DB::table('pegawai')->insert([
             'nip' => $request->post('nip'),
            'nama' => $request->post('nama'),
            'divisi' => $request->post('divisi'),
            'bagian' => $request->post('bagian'),
            'jabatan' => $request->post('jabatan'),
        ]);
        if ($simpan) {
            Session::flash('sukses', 'Data berhasil disimpan.');
        } else {
            Session::flash('sukses', 'Data gagal disimpan.');
        }
        return redirect('pegawai');
    }

    public function edit_pegawai(Request $request)
    {
        $data = Pegawai::findOrFail($request->get('id'));
        echo json_encode($data);
    }

    public function update_pegawai(Request $request)

    {
        $data = array(
            'nama' => $request->post('nama'),
            'jabatan' => $request->post('jabatan'),
            'wilayah' => $request->post('wilayah'),
            'area' => $request->post('area'),
            'status' => 1,
        );
        $simpan = DB::table('pegawai')->where('id', '=', $request->post('id'))->update($data);
        if ($simpan) {
            Session::flash('status', 'Data berhasil diupdate.');
        } else {
            Session::flash('status', 'Data gagal diupdate.');
        }
        return redirect('pegawai')->with("sukses", "berhasil diubah");
    }

    public function pegawai_hapus($id)
    {
        // hapus kategori berdasarkan id yang dipilih
        $handphone = Pegawai::find($id);
        $handphone->delete();

        return redirect('pegawai')->with("sukses", " berhasil dihapus");
    }

    //---------------------------------------------------------------------------------------//
    //---------------------------------------------------------------------------------------//


    public function kendaraan()
    {
        $kendaraan = Kendaraan::all();
        $kendaraanedit = Kendaraan::all();
        return view('kendaraan', ['kendaraan' => $kendaraan, 'kendaraanedit'=> $kendaraanedit]);
    }

    public function simpan_kendaraan(Request $request)
    {
        $simpan = DB::table('kendaraan')->insert([
            'jenisKendaraan' => $request->post('jenisKendaraan'),
            'noPolisi' => $request->post('noPolisi'),
            'noMesin' => $request->post('noMesin'),
            'noRangka' => $request->post('noRangka'),
            'merek' => $request->post('merek'),
            'warna' => $request->post('warna'),
            'status' => 1,
        ]);


        if ($simpan) {
            Session::flash('status', 'Data berhasil disimpan.');
        } else {
            Session::flash('status', 'Data gagal disimpan.');
        }
        return redirect('kendaraan');
    }

    public function edit_kendaraan(Request $request)
    {
        $data = Kendaraan::findOrFail($request->get('id'));
        echo json_encode($data);
    }

    public function update_kendaraan(Request $request)

    {
        $data = array(
            'jenisKendaraan' => $request->post('jenisKendaraan'),
            'noPolisi' => $request->post('noPolisi'),
            'noMesin' => $request->post('noMesin'),
            'noRangka' => $request->post('noRangka'),
            'merek' => $request->post('merek'),
            'warna' => $request->post('warna'),
            'status' => 1,
        );
        $simpan = DB::table('kendaraan')->where('id', '=', $request->post('id'))->update($data);
        if ($simpan) {
            Session::flash('status', 'Data berhasil diupdate.');
        } else {
            Session::flash('status', 'Data gagal diupdate.');
        }
        return redirect('kendaraan')->with("sukses", "berhasil diubah");
    }

    public function kendaraan_hapus($id)
    {
        // hapus kategori berdasarkan id yang dipilih
        $kendaraan = Kendaraan::find($id);
        $kendaraan->delete();

        return redirect('kendaraan')->with("sukses", "inventaris berhasil dihapus");
    }


    //---------------------------------------------------------------------------------------//
    //---------------------------------------------------------------------------------------//

    //---------------------------------------------------------------------------------------//
    //---------------------------------------------------------------------------------------//


    public function peminjaman()
    {
        $peminjaman = Peminjaman::orderBy('id', 'DESC')->get();
        $pegawai = Pegawai::all();
        $pegawaiedit = Pegawai::all();
        $kendaraan = Kendaraan::all();
       
        return view('peminjaman', ['peminjaman' => $peminjaman, 'kendaraan'=> $kendaraan, 'pegawai'=> $pegawai, 'pegawaiedit'=> $pegawaiedit]);
    }

    public function simpan_peminjaman(Request $request)
    {
        $simpan = DB::table('peminjaman')->insert([
            'tanggal' => $request->post('tanggal'),
            'noForm' => $request->post('noForm'),
            'id_pegawai' => $request->post('id_pegawai'),
            'id_kendaraan' => 5,
            'namaSupir' => $request->post('namaSupir'),
            'lamaPinjam' => $request->post('lamaPinjam'),
            'keperluan' => $request->post('keperluan'),
            'status'    => 1,
        ]);


        if ($simpan) {
            Session::flash('status', 'Data berhasil disimpan.');
        } else {
            Session::flash('status', 'Data gagal disimpan.');
        }
        return redirect('peminjaman')->with("sukses", "Berhasil di tambah");
    }

    public function edit_peminjaman(Request $request)
    {
        $data = Peminjaman::findOrFail($request->get('id'));
        echo json_encode($data);
    }

    public function update_peminjaman(Request $request)

    {
        $data = array(
            'tanggal' => $request->post('tanggal'),
            'noForm' => $request->post('noForm'),
            'id_pegawai' => $request->post('id_pegawai'),
            'namaSupir' => $request->post('namaSupir'),
            'lamaPinjam' => $request->post('lamaPinjam'),
            'keperluan' => $request->post('keperluan'),
            'status' => 1,
        );
        $simpan = DB::table('peminjaman')->where('id', '=', $request->post('id'))->update($data);
        if ($simpan) {
            Session::flash('status', 'Data berhasil diupdate.');
        } else {
            Session::flash('status', 'Data gagal diupdate.');
        }
        return redirect('peminjaman')->with("sukses", "berhasil diubah");
    }

    public function peminjaman_hapus($id)
    {
        // hapus kategori berdasarkan id yang dipilih
        $peminjaman = Peminjaman::find($id);
        $peminjaman->delete();

        return redirect('peminjaman')->with("sukses", "berhasil dihapus");
    }


    //---------------------------------------------------------------------------------------//
    //---------------------------------------------------------------------------------------//

    //---------------------------------------------------------------------------------------//
    //---------------------------------------------------------------------------------------//


    public function pengajuan()
    {
        $pengajuan = Peminjaman::orderBy('id', 'DESC')->get();
        $pengajuanedit = Pegawai::all();
        $kendaraan = Kendaraan::where('id','!=',5)->where('status','=','1')->get();

        return view('pengajuan', ['pengajuan' => $pengajuan, 'pengajuanedit' => $pengajuanedit, 'kendaraan' => $kendaraan]);
    }


    public function edit_pengajuan(Request $request)
    {
        $data = Peminjaman::findOrFail($request->get('id'));
        echo json_encode($data);
    }

    public function update_pengajuan(Request $request)

    {
        $data = array(
            'id_kendaraan' => $request->post('id_kendaraan'),
            'disetujuiOleh' => "Sekper",
            'status' => 2,
        );

        $simpan = DB::table('peminjaman')->where('id', '=', $request->post('id'))->update($data);

        $simpanstatuspegawai = DB::table('kendaraan')->where('id', '=', $request->post('id_kendaraan'))->update(['status' => 2]);


        if ($simpan) {
            Session::flash('status', 'Data berhasil diterima.');
        } else {
            Session::flash('status', 'Data gagal diterima.');
        }
        return redirect('pengajuan')->with("sukses", "berhasil");
    }



    //---------------------------------------------------------------------------------------//
    //---------------------------------------------------------------------------------------//

    //---------------------------------------------------------------------------------------//
    //---------------------------------------------------------------------------------------//


    public function surat_jalan($id)
    {
        $peminjaman = Peminjaman::find($id);
        // $pengajuanedit = Pegawai::all();
        // $kendaraan = Kendaraan::where('id', '!=', 5)->where('status', '=', '1')->get();

        return view('surat_jalan', ['peminjaman'=> $peminjaman]);
    }


    public function edit_peminjaman_selesai(Request $request)
    {
        $data = Peminjaman::findOrFail($request->get('id'));
        echo json_encode($data);
    }


    public function update_selesai(Request $request)

    {
       
        $fotoawal = $request->file('foto_kmawal')->getClientOriginalName();
        $fotoakhir = $request->file('foto_kmakhir')->getClientOriginalName();

        $save = new Peminjaman;
        $save->foto_kmawal=$fotoawal;
        $save->foto_kmakhir = $fotoakhir;
        $save->update();
 

        $data = array(
            // 'tgl_kembali' => $request->post('tgl_kembali'),
            'kmAwal' => $request->post('kmAwal'),
            'kmAkhir' => $request->post('kmAkhir'),
            // 'status' => 3,
        );

        $file1 = $request->file('foto_kmawal');
        $file2 = $request->file('foto_kmakhir');

        $nama_file1 = time() . "_" . $file1->getClientOriginalName();
        $nama_file2 = time() . "_" . $file2->getClientOriginalName();

        $tujuan_upload = 'data_file';

        $file1->move($tujuan_upload,$nama_file1);
        $file2->move($tujuan_upload,$nama_file2);

        $upload1 = DB::table('peminjaman')->where('id', '=', $request->post('id_selesai'))->update(['foto_kmawal'=>$nama_file1]);
        $upload2 = DB::table('peminjaman')->where('id', '=', $request->post('id_selesai'))->
        update(['foto_kmakhir' => $nama_file2]);
        $simpan = DB::table('peminjaman')->where('id', '=', $request->post('id_selesai'))->update($data);

        $simpanstatusmobil = DB::table('kendaraan')->where('id', '=', $request->post('id_kendaraan_edit'))->update(['status' => 1]);

        if ($simpan) {
            Session::flash('status', 'Data berhasil diterima.');
        } else {
            Session::flash('status', 'Data gagal diterima.');
        }
        return redirect('peminjaman')->with("sukses", "berhasil");
    }

    public function edit_terima(Request $request)
    {
        $data = Peminjaman::findOrFail($request->get('id'));
        echo json_encode($data);
    }

    public function update_terima(Request $request){
        $data = array(
            'tgl_kembali' => $request->post('tgl_kembali'),
            'terlambat' => $request->post('terlambat'),
            'status' => 3,
        );
        $simpan = DB::table('peminjaman')->where('id', '=', $request->post('id_terima'))->update($data);

        if ($simpan) {
            Session::flash('status', 'Data berhasil diterima.');
        } else {
            Session::flash('status', 'Data gagal diterima.');
        }
        return redirect('pengajuan')->with("sukses", "berhasil");
    }

    public function detail_peminjaman($id)
    {
        $peminjaman = Peminjaman::find($id);
        return view('detail_peminjaman', ['peminjaman' => $peminjaman]);
    }

    //---------------------------------------------------------------------------------------//
    //---------------------------------------------------------------------------------------//

    //---------------------------------------------------------------------------------------//
    //---------------------------------------------------------------------------------------//

    public function tamu()
    {
        $tamu_get = Tamu::where('status', '=', 1)->count();
        if ($tamu_get == 0) {
            $tamu = Tamu::orderBy('id', 'DESC')->where('status', '=', 2)->get();
        } else {
            $tamu = Tamu::orderBy('id', 'DESC')->where('status', '=', 1)->get();
        }
        $record_tamu = Tamu::orderBy('id', 'DESC')->where('status', '=', 2)->get();
        $tamuedit = Tamu::orderBy('id', 'DESC')->get();
        return view('tamu', ['tamu' => $tamu, 'record_tamu' => $record_tamu,'tamu_get' => $tamu_get]);
    }

    public function simpan_tamu(Request $request)
    {
        // $fotoawal = $request->file('foto_kmawal')->getClientOriginalName();
        // $fototamu = $request->file('foto')->getClientOriginalName();
       
        $file = $request->file('foto');
        $nama_file = time() . "_" . $file->getClientOriginalName();
        $tujuan_upload = public_path();
        $file->move($tujuan_upload, $nama_file);

        $simpan = DB::table('tamu')->insert([
            'waktu_masuk' => $request->post('waktu_masuk'),
            'no_identitas' => $request->post('no_identitas'),
            'nama' => $request->post('nama'),
            'no_tlp' => $request->post('no_tlp'),
            'perihal' => $request->post('perihal'),
            'divisi_tujuan' => $request->post('divisi_tujuan'),
            'asal_instansi' => $request->post('asal_instansi'),
            'alamat' => $request->post('alamat'),
            'no_kendaraan' => $request->post('no_kendaraan'),
            'status'    => 1,
            'foto' => $nama_file,
        ]);

        if ($simpan) {
            Session::flash('status', 'Data berhasil disimpan.');
        } else {
            Session::flash('status', 'Data gagal disimpan.');
        }
        return redirect('tamu')->with("sukses", "Berhasil di tambah");
    }

    public function edit_tamu(Request $request)
    {
        $data = Tamu::findOrFail($request->get('id'));
        echo json_encode($data);
    }

    public function update_tamu(Request $request)

    {

        if (!empty($request->file('foto_update'))) {
            $data = array(
                'waktu_masuk' => $request->post('waktu_masuk'),
                'no_identitas' => $request->post('no_identitas'),
                'nama' => $request->post('nama'),
                'no_tlp' => $request->post('no_tlp'),
                'perihal' => $request->post('perihal'),
                'divisi_tujuan' => $request->post('divisi_tujuan'),
                'asal_instansi' => $request->post('asal_instansi'),
                'alamat' => $request->post('alamat'),
                'no_kendaraan' => $request->post('no_kendaraan'),
                'status'    => 1,
                // 'foto' => $nama_file,
            );

            $simpan = DB::table('tamu')->where('id', '=', $request->post('id'))->update($data);

            $file = $request->file('foto_update');
            $nama_file = time() . "_" . $file->getClientOriginalName();
            $tujuan_upload = public_path();
            $file->move($tujuan_upload, $nama_file);

            $data2 = array('foto' => $nama_file);

            $simpan2 = DB::table('tamu')->where('id', '=', $request->post('id'))->update($data2);

            if ($simpan) {
                Session::flash('status', 'Data berhasil diupdate.');
            } else {
                Session::flash('status', 'Data gagal diupdate.');
            }
            return redirect('tamu')->with("sukses", "berhasil diubah");
        } else {
            $data = array(
                'waktu_masuk' => $request->post('waktu_masuk'),
                'no_identitas' => $request->post('no_identitas'),
                'nama' => $request->post('nama'),
                'no_tlp' => $request->post('no_tlp'),
                'perihal' => $request->post('perihal'),
                'divisi_tujuan' => $request->post('divisi_tujuan'),
                'asal_instansi' => $request->post('asal_instansi'),
                'alamat' => $request->post('alamat'),
                'no_kendaraan' => $request->post('no_kendaraan'),
                'status'    => 1,
                // 'foto' => $nama_file,
            );

            $simpan = DB::table('tamu')->where('id', '=', $request->post('id'))->update($data);


            if ($simpan) {
                Session::flash('status', 'Data berhasil diupdate.');
            } else {
                Session::flash('status', 'Data gagal diupdate.');
            }
            return redirect('tamu')->with("sukses", "berhasil diubah");
        }

       
    }

    public function tamu_hapus($id)
    {
        // hapus kategori berdasarkan id yang dipilih
        $tamu = Tamu::find($id);
        $tamu->delete();

        return redirect('tamu')->with("sukses", "berhasil dihapus");
    }

    public function tamu_keluar($id)
    {
        // hapus kategori berdasarkan id yang dipilih
        $tamu_keluar = Tamu::find($id);
        $data = array(
            'waktu_keluar' => date("Y-m-d h:i:s"),
            'status'    => 2,
        );
        $simpan2 = DB::table('tamu')->where('id', '=', $id )->update($data);
        return redirect('tamu')->with("sukses", "berhasil");
    }

    public function detail_tamu($id)
    {
        $tamu = Tamu::find($id);
        return view('detail_tamu', ['tamu' => $tamu]);
    }

    public function tambah_ajax(Request $request)
    {
        $contact = new Tamu;
        $contact->waktu_masuk    = $request->waktu_masuk;
        $contact->no_identitas    = $request->no_identitas;
        $contact->nama    = $request->nama;
        $contact->no_tlp    = $request->no_tlp;
        $contact->perihal    = $request->perihal;
        $contact->divisi_tujuan    = $request->divisi_tujuan;
        $contact->asal_instansi = $request->asal_instansi;
        $contact->alamat = $request->alamat;
        $contact->no_kendaraan = $request->no_kendaraan;
        $contact->foto = $request->foto_tamu_tambah;
        $contact->save();

        if ($contact) {
            #tampilkan message sukses
            $arr = array('msg' => 'Berhasil di Input', 'status' => true);
        }
        return Response()->json($arr);
    }
    public function tamu_tambah(){
        return view('tamu_tambah');
    } 
      
}